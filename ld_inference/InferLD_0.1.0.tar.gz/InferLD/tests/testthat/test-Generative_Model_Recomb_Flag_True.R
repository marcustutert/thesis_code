test_that("Generative Model Non-Recombination Recombination Flag True", {
  library(matrixStats)
  print(getwd())
  r2_true_inferred_af_across_chains = function(inferred_allele_freq, #Matrix across chains
                                               true_allele_freq,
                                               graphic = FALSE,
                                               nhaps,
                                               nSamples){    #Vector of AFs
    nSamples = nSamples
    r2       = c()
    for (i in (1:((nSamples-1)*nhaps+1))) {
      r2[i] = summary(lm(inferred_allele_freq[,i]~true_allele_freq))$r.squared
    }
    if (graphic == FALSE) {
      return(r2)
    }
    else{
      #Create plot
      fig <- plot_ly(data = iris, x = ~seq(1:nSamples), y = ~r2)
      fig <- fig %>% layout(title = 'Correlation of True to Inferred Allele Frequency Across Sweeps',
                            xaxis = list(title = 'nSamples (Full Sweeps)'),
                            yaxis = list(title = 'r2 correlation (Inferred~True)'))
      return(fig)
    }
  }

  ref_hap_panel    = read.table("./Data/ref_hap_panel")
  print(dim(ref_hap_panel))
  observed_gwas_se = read.table("./Data/observed_gwas_se_generative_drifted")[,1]
  gwas_variants_af = read.table("./Data/gwas_variants_af")[,1]
  nSamples         = 3
  #Use some generative model data that we have simulated under a model of no genetic drift
  results                             = LD_from_GSHMM(ref_panel_haplotypes = ref_hap_panel[1:200,1:10],
                                                      fst                   = 0.001,
                                                      betas                 = FALSE,
                                                      alpha                 = 1e3,
                                                      nSamples              = 10,
                                                      recomb_rate           = 1e-100,
                                                      weights_resolution    = 5,
                                                      likelihood_toggle     = TRUE,
                                                      se_observed           = observed_gwas_se[1:10],
                                                      LD_Infer              = T,
                                                      genetic_map           = FALSE,
                                                      chain_likelihood      = TRUE,
                                                      nChains               = 1,
                                                      recombination         = F,
                                                      case_control_constant = 1,
                                                      BurnIn                = T)
  r2 = r2_true_inferred_af_across_chains(inferred_allele_freq = results[[3]],
                                         true_allele_freq     = gwas_variants_af[1:10],
                                         graphic              = FALSE,
                                         nSamples             = 10,
                                         nhaps                = nrow(ref_hap_panel[1:200,1:10]))
  r2_post_burn_in = mean(r2[(.9*length(r2)):length(r2)])
  print(r2[length(r2)])
  print(r2_post_burn_in)
  expect_gt(r2_post_burn_in, 0.98)})

