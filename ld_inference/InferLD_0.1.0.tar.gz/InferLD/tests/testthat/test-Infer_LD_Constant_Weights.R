test_that("Constant Weights Recovering Expected LD", {


  #Generate an example of a HW weight matrix (that will be UNnormalized) where the weights do not vary along the region
  HW_Matrix = cbind(c(4,1,2),c(4,1,2),c(4,1,2),c(4,1,2))

  #Create a Reference Haplotype Panel (Coded 0 & 1 as convention), this will have dimensions nhaps x nsnps
  nsnps = ncol(HW_Matrix)
  nhaps = nrow(HW_Matrix)

  ref_allele_matrix =  cbind(c(0,1,0),c(1,0,0),c(0,0,1),c(1,0,0))

  #Manually calculate the LD between pairs of variants and get a matrix of the LD r to compare to
  #Check notebook to see how this is done
  Qx = markovian_flow(HW_Matrix = HW_Matrix,start = 1, end = nsnps, recombination = F)
  LD = LD_flow_expectation(HW_Matrix = HW_Matrix,ref_allele_matrix = ref_allele_matrix,Qx_array = Qx, recombination = FALSE)

  true_LD = as.matrix(read.table("./Data/true_LD_constant_weights",header = F))
  expect_equal(object   =  c(LD),
               expected =  c(true_LD),
               tolerance = 1e-5)})
