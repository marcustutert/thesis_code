#!/usr/bin/env Rscript

## this is a simple script to profile R code
library("proftools")

## change directory to one up from scripts, no matter how this was called
args <- commandArgs(trailingOnly = FALSE)
for(key in c("--file=", "--f=")) {
    i <- substr(args, 1, nchar(key)) == key
    if (sum(i) == 1) {
        script_dir <- dirname(substr(args[i], nchar(key) + 1, 1000))
        setwd(file.path(script_dir, "../"))
        pkg_dir <- getwd()
    }
}

## here we load all the functions from LDInfer into RAM
library("InferLD")
setwd(paste0(pkg_dir, "/R"))
a <- dir(pattern = "*R")
b <- grep("~", a)
if (length(b) > 0) {
    a <- a[-b]
}
o <- sapply(a, source)
setwd(pkg_dir)


profout <- tempfile()
Rprof(file = profout, gc.profiling = TRUE, line.profiling = TRUE)
profile_start <- Sys.time()
################## start of code to profile
  set.seed(245)

  #Set number of haplotypes and variants to a small number so we can do testing and debugging
  nhaps     = 10  #Haplotypes in the reference panel
  nsnps     = 300 #Variants in the reference panel
  nSamples  = 100
  ## path = dirname(getwd()) #Set path relative to testing folder
  path <- getwd()

  #Load in 1000G data from ./Test/Data
  ref_hap_panel     = as.matrix(read.table(sprintf('%s/tests/Data/ref_panel_filtered',path),
                                             header = TRUE))

  #Subset to nhaps and nsnps size to make testing easier
  ref_hap_panel     = ref_hap_panel[ 1:nhaps, 1:nsnps ]

  #Get AF of the variants in the reference pnale
  ref_variants_af   = colMeans(ref_hap_panel)
  Fst               = 1e-5

  #Assume that allele frequencies are the same in the reference panel and the GWAS panel
  sample_weights           = rgamma(n = nhaps, shape =  1 / ( nhaps * (Fst/(1-Fst))), scale =  1 / ( nhaps * (Fst/(1-Fst))))
  normalize_sample_weights = sample_weights/(sum(sample_weights))
  gwas_variants_af         = colSums(ref_hap_panel * normalize_sample_weights)

  #Filter out SNPs that are above/below a threshhold (0-100% exclusive)
  filter_snp_index        = which(colMeans(ref_hap_panel) > 0.99)
  filter_snp_index_2      = which(colMeans(ref_hap_panel) < 0.01)
  filter_snp_index_merged = c(filter_snp_index,filter_snp_index_2)
  if (length(filter_snp_index_merged)>0) {
    ref_hap_panel     = ref_hap_panel[,-filter_snp_index_merged]
    gwas_variants_af  = gwas_variants_af[-filter_snp_index_merged]
    ref_variants_af   = ref_variants_af[-filter_snp_index_merged]
  }
  #Transform AF's to SE
  observed_gwas_se  = 1/(gwas_variants_af*(1-gwas_variants_af))
  results           = LD_from_GSHMM(ref_panel_haplotypes = ref_hap_panel,
                                    Fst                  = 1e-3,
                                    betas                = FALSE,
                                    alpha                = 1e3,
                                    nSamples             = nSamples,
                                    recomb_rate          = 1e-10,
                                    weights_resolution   = 10,
                                    likelihood_toggle    = TRUE,
                                    se_observed          = observed_gwas_se,
                                    LD_Infer             = TRUE,
                                    genetic_map          = FALSE,
                                    chain_likelihood     = TRUE,
                                    nChains              = 1)
# ################## end of code to profile
profile_end <- Sys.time()

Rprof(NULL)
pd <- readProfileData(profout)
title <- Sys.getenv("TITLE")

output_plot <- Sys.getenv("OUTPUT_PLOT")
if (output_plot == "") {
    setwd(pkg_dir)
    output_plot <- file.path("profile.pdf")
}
pdf(output_plot, height = 24, width = 24)
par(mfrow = c(3, 1), oma=c(0, 0, 3, 0))
flameGraph(pd, order = "time", main = "Time")
flameGraph(pd, order = "alpha", main = "Alphabetically")
flameGraph(pd, order = "hot", main = "Hot path")
title(title, outer=TRUE)
dev.off()

print(profile_end - profile_start)
