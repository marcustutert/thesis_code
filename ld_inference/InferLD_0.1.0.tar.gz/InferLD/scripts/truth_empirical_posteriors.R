#Profvis profiling of the code

#Set number of haplotypes and variants to a small number so we can do testing and debugging
nhaps = 200 #Haplotypes in the reference panel
nsnps = 20 #Variants in the reference panel

## path = dirname(getwd()) #Set path relative to testing folder
path <- getwd()

#Load in 1000G data from ./Test/Data
ref_hap_panel     = as.matrix(read.table(sprintf('%s/tests/Data/ref_panel_filtered',path),
                                         header = TRUE))

#Subset to nhaps and nsnps size to make testing easier
ref_hap_panel     = ref_hap_panel[ 1:nhaps, 1:nsnps ]

#Get AF of the variants in the reference pnale
ref_variants_af   = colMeans(ref_hap_panel)
Fst               = 1e-2

#Assume that allele frequencies are the same in the reference panel and the GWAS panel
sample_weights           = rgamma(n = nhaps, shape =  1 / ( nhaps * (Fst/(1-Fst))), scale =  1 / ( nhaps * (Fst/(1-Fst))))
normalize_sample_weights = sample_weights/(sum(sample_weights))
gwas_variants_af         = colSums(ref_hap_panel * normalize_sample_weights)

#Filter out SNPs that are above/below a threshhold (0-100% exclusive)
filter_snp_index        = which(colMeans(ref_hap_panel) > 0.99)
filter_snp_index_2      = which(colMeans(ref_hap_panel) < 0.01)
filter_snp_index_merged = c(filter_snp_index,filter_snp_index_2)
if (length(filter_snp_index_merged)>0) {
  ref_hap_panel     = ref_hap_panel[,-filter_snp_index_merged]
  gwas_variants_af  = gwas_variants_af[-filter_snp_index_merged]
  ref_variants_af   = ref_variants_af[-filter_snp_index_merged]
}

#Transform AF's to SE
nSamples          = 10
alpha             = 1e4
fig <- plot_ly(z = ref_hap_panel, type = "heatmap")
#fig
observed_gwas_se  = 1/(gwas_variants_af*(1-gwas_variants_af))
Fst_0001           = LD_from_GSHMM(ref_panel_haplotypes = ref_hap_panel,
                                  Fst                  = 0.001,
                                  betas                = FALSE,
                                  alpha                = alpha,
                                  nSamples             = nSamples,
                                  recomb_rate          = 1e-100,
                                  weights_resolution   = 5,
                                  likelihood           = TRUE,
                                  se_observed          = observed_gwas_se,
                                  LD_Infer             = FALSE,
                                  genetic_map          = FALSE,
                                  chain_likelihood     = TRUE)

Fst_001           = LD_from_GSHMM(ref_panel_haplotypes = ref_hap_panel,
                                   Fst                  = 0.01,
                                   betas                = FALSE,
                                   alpha                = alpha,
                                   nSamples             = nSamples,
                                   recomb_rate          = 1e-100,
                                   weights_resolution   = 5,
                                   likelihood           = TRUE,
                                   se_observed          = observed_gwas_se,
                                   LD_Infer             = FALSE,
                                   genetic_map          = FALSE,
                                   chain_likelihood     = TRUE)

Fst_01           = LD_from_GSHMM(ref_panel_haplotypes = ref_hap_panel,
                                  Fst                  = 0.1,
                                  betas                = FALSE,
                                  alpha                = alpha,
                                  nSamples             = nSamples,
                                  recomb_rate          = 1e-100,
                                  weights_resolution   = 5,
                                  likelihood           = TRUE,
                                  se_observed          = observed_gwas_se,
                                  LD_Infer             = FALSE,
                                  genetic_map          = FALSE,
                                  chain_likelihood     = TRUE)
fig <- plot_ly(data = iris, x = ~seq(1:nSamples))
fig <- fig %>% add_trace(y = ~Fst_0001[[3]], name = 'Fst = 0.001',mode = 'markers')
fig <- fig %>% add_trace(y = ~Fst_001[[3]], name = 'Fst = 0.01', mode = 'markers')
fig <- fig %>% add_trace(y = ~Fst_01[[3]], name = 'Fst = 0.1', mode = 'markers')
fig

######Comparing Empirical and Truth#######
#Profvis profiling of the code

#Set number of haplotypes and variants to a small number so we can do testing and debugging
nhaps = 3 #Haplotypes in the reference panel
nsnps = 100 #Variants in the reference panel

## path = dirname(getwd()) #Set path relative to testing folder
path <- getwd()

#Load in 1000G data from ./Test/Data
ref_hap_panel     = as.matrix(read.table(sprintf('%s/tests/Data/ref_panel_filtered',path),
                                         header = TRUE))

#Subset to nhaps and nsnps size to make testing easier
ref_hap_panel     = ref_hap_panel[ 1:nhaps, 1:nsnps ]

#Get AF of the variants in the reference pnale
ref_variants_af   = colMeans(ref_hap_panel)
Fst               = 1e-5

#Assume that allele frequencies are the same in the reference panel and the GWAS panel
sample_weights           = rgamma(n = nhaps, shape =  1 / ( nhaps * (Fst/(1-Fst))), scale =  1 / ( nhaps * (Fst/(1-Fst))))
normalize_sample_weights = sample_weights/(sum(sample_weights))
gwas_variants_af         = colSums(ref_hap_panel * normalize_sample_weights)

#Filter out SNPs that are above/below a threshhold (0-100% exclusive)
filter_snp_index        = which(colMeans(ref_hap_panel) > 0.99)
filter_snp_index_2      = which(colMeans(ref_hap_panel) < 0.01)
filter_snp_index_merged = c(filter_snp_index,filter_snp_index_2)
if (length(filter_snp_index_merged)>0) {
  ref_hap_panel     = ref_hap_panel[,-filter_snp_index_merged]
  gwas_variants_af  = gwas_variants_af[-filter_snp_index_merged]
  ref_variants_af   = ref_variants_af[-filter_snp_index_merged]
}
observed_gwas_se  = 1/(gwas_variants_af*(1-gwas_variants_af))
alpha    = 1e4
nSamples = 10000
set.seed(341)
results           = LD_from_GSHMM(ref_panel_haplotypes = ref_hap_panel,
                                 Fst                  = 1e-3,
                                 betas                = FALSE,
                                 alpha                = alpha,
                                 nSamples             = nSamples,
                                 recomb_rate          = 1e-100,
                                 weights_resolution   = 3,
                                 likelihood           = TRUE,
                                 se_observed          = observed_gwas_se,
                                 LD_Infer             = FALSE,
                                 genetic_map          = FALSE,
                                 chain_likelihood     = TRUE,
                                 recombination        = FALSE,
                                 nChains              = 1)
#
####Emprically calculate the number of iterations
config_number = nhaps ^ 3
vec <- apply(results[[1]][[5]], 2, paste, collapse=" ")
config         = f6(vec)$x[1:config_number]
config_prob    = f6(vec)$N[1:config_number]/nSamples
empirical_mat  = matrix(data = NA, nrow = config_number, ncol = 3)
#Convert to numeric and store in matrix
for (i in 1:length(config)) {
  empirical_mat[i,1:3] = cbind(as.integer(unlist(strsplit(config[i], " "))))
}
empirical_mat          = cbind(empirical_mat,config_prob)
empirical_mat[order(empirical_mat[,4],decreasing = TRUE),]

likelihood = function(weights,ref_hap_panel,observed_gwas_se,alpha,Fst){
  gamma_weights = qgamma(p = (1:length(weights))/(1+length(weights)), shape = 1 / ( nhaps * (Fst/(1-Fst))), scale = ( nhaps * (Fst/(1-Fst))))
  #Generate the gamma quantiles from the weight state space
  gamma_weights_state = c()
  for (i in 1:length(weights)) {
    gamma_weights_state[i] = gamma_weights[weights[i]] #This find which configuration has what weight state space values
  }
  weight_matrix                = matrix(gamma_weights_state, nrow=nrow(ref_hap_panel), ncol=ncol(ref_hap_panel), byrow=TRUE)
  weight_matrix_sum            = colSums(weight_matrix)
  if (length(weight_matrix_sum) == 1) {
    weight_matrix_normalized    = weight_matrix/weight_matrix_sum
  }
  else{
    weight_matrix_normalized      = weight_matrix %*% diag(1/weight_matrix_sum)
  }
  inferred_af_given_weights    = colSums(weight_matrix_normalized * ref_hap_panel)
  implied_se                   = 1/(inferred_af_given_weights*(1-inferred_af_given_weights))
  ratio                        = observed_gwas_se/implied_se
  prob_observed                = sum(dgamma(ratio, shape=alpha, rate=alpha, log=T))  #Keep this in log space
  return(prob_observed)
}

#Run test
nhaps <- 3
Fst   <- 1e-3
weights_resolution <- 3
truth_prob = cbind(as.matrix(expand.grid(1:3,1:3,1:3,stringsAsFactors = FALSE)),rep(0,27))
for (i in 1:nrow(truth_prob)) {
  truth_prob[i,4] <- likelihood(weights = c(truth_prob[i,1],truth_prob[i,2],truth_prob[i,3]), ref_hap_panel = as.matrix(ref_hap_panel), observed_gwas_se = observed_gwas_se, alpha = alpha, Fst = Fst) #Ask what is the prior probaility for that configuration
}
truth_prob[,4] = exp(truth_prob[,4])/sum(exp(truth_prob[,4]))
truth_prob = truth_prob[order(truth_prob[,4],decreasing = TRUE),]

#Combine columns together
truth_prob[,1]    = paste(truth_prob[,1],truth_prob[,2],truth_prob[,3])
truth_prob        = truth_prob[,c(1,4)]
empirical_mat[,1] = paste(empirical_mat[,1],empirical_mat[,2],empirical_mat[,3])
empirical_mat     = empirical_mat[,c(1,4)]
colnames(empirical_mat) <- c("Config","Prob")
colnames(truth_prob) <- c("Config","Prob")
newtable <- merge(truth_prob,empirical_mat, by = "Config", all.x = TRUE)
colnames(newtable) = c("Config", "Truth", "Empirically")
newtable
