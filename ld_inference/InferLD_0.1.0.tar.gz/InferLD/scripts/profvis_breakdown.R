#Profvis profiling of the code
library(profvis)
profvis({
#Set number of haplotypes and variants to a small number so we can do testing and debugging
nhaps = 808 #Haplotypes in the reference panel
nsnps = 471 #Variants in the reference panel

## path = dirname(getwd()) #Set path relative to testing folder
path <- getwd()

#Load in 1000G data from ./Test/Data
ref_hap_panel     = as.matrix(read.table(sprintf('%s/tests/Data/ref_panel_filtered',path),
                                         header = TRUE))

#Subset to nhaps and nsnps size to make testing easier
ref_hap_panel     = ref_hap_panel[ 1:nhaps, 1:nsnps ]

#Get AF of the variants in the reference pnale
ref_variants_af   = colMeans(ref_hap_panel)
Fst               = 1e-4

#Assume that allele frequencies are the same in the reference panel and the GWAS panel
sample_weights           = rgamma(n = nhaps, shape =  1 / ( nhaps * (Fst/(1-Fst))), scale =  1 / ( nhaps * (Fst/(1-Fst))))
normalize_sample_weights = sample_weights/(sum(sample_weights))
gwas_variants_af         = colSums(ref_hap_panel * normalize_sample_weights)

#Filter out SNPs that are above/below a threshhold (0-100% exclusive)
filter_ref_snp_index_1       = which(colMeans(ref_hap_panel) > 0.97)
filter_ref_snp_index_2       = which(colMeans(ref_hap_panel) < 0.03)
filter_gwas_snp_index_1      = which(gwas_variants_af > 0.97)
filter_gwas_snp_index_2      = which(gwas_variants_af < 0.03)
filter_snp_index_merged = c(filter_ref_snp_index_1,filter_ref_snp_index_2,filter_gwas_snp_index_1,filter_gwas_snp_index_2)
if (length(filter_snp_index_merged)>0) {
  ref_hap_panel     = ref_hap_panel[,-filter_snp_index_merged]
  gwas_variants_af  = gwas_variants_af[-filter_snp_index_merged]
  ref_variants_af   = ref_variants_af[-filter_snp_index_merged]
}
observed_gwas_se  = 1/(gwas_variants_af*(1-gwas_variants_af))

#Transform AF's to SE
nSamples          = 5
alpha             = 1e3
alpha             = 10
fig <- plot_ly(z = ref_hap_panel, type = "heatmap")
#fig
observed_gwas_se  = 1/(gwas_variants_af*(1-gwas_variants_af))
test           = LD_from_GSHMM(ref_panel_haplotypes = ref_hap_panel,
                                   Fst                  = 1e-1,
                                   betas                = FALSE,
                                   alpha                = alpha,
                                   nSamples             = nSamples,
                                   recomb_rate          = 1e-10,
                                   weights_resolution   = 5,
                                   likelihood           = TRUE,
                                   se_observed          = observed_gwas_se,
                                   LD_Infer             = FALSE,
                                   genetic_map          = FALSE,
                                   chain_likelihood     = TRUE,
                                   nChains              = 1,
                                   recombination        = FALSE)
})


