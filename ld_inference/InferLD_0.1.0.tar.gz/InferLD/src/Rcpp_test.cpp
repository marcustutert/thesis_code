#include <Rcpp.h>
using namespace Rcpp;
// [[Rcpp::export]]
NumericMatrix allele_freq_across_states_and_snps(NumericVector gamma_weight_states,
                                                 IntegerMatrix ref_allele_matrix,
                                                 NumericMatrix weight_matrix,
                                                 int row_update) {
  // Record the number of SNPs
  int nsnps                 = ref_allele_matrix.ncol();
  int zero_based_row_update = row_update - 1;                            //Convert from R to Rcpp index (1->0)
  NumericMatrix allele_frequencies(gamma_weight_states.length(), nsnps); //Initialize the matrix with dim: (nstates,nsnps)
  double w = 0;
  for (int i = 0; i < nsnps; i++) {                                      //Loop through the variants
    for(int k = 0; k < gamma_weight_states.length(); k++) {              //Loop through the Gamma Weight States
      double val = 0;                                                    //Initialize values
      double denom = 0;                                                  //Initialize values
      for(int j = 0; j < weight_matrix.nrow(); j++) {                    //Loop through haplotypes
        if (j == (zero_based_row_update)) {                              //If we are on the row that we are updating
          w = gamma_weight_states(k);                                    //Set w equal to current weight state
        } else {
          w = weight_matrix(j, i);                                       // This gives you the value in the jth SNP of the ith haplotype
        }
        val += w * ref_allele_matrix(j, i);                             
        denom += w;
      }
      allele_frequencies(k, i) =  val / denom;
    }
  }
  return((allele_frequencies));
}

// [[Rcpp::export]]
NumericMatrix forward_pass_c(NumericMatrix allele_frequency_matrix,
                             double        diag_transition) {
  //Get Matrix Constants
  double nsnps   = allele_frequency_matrix.ncol();
  double nstates = allele_frequency_matrix.nrow();

  double     c = (1-diag_transition)/(nstates-1);
  double     a = diag_transition - c;

  NumericMatrix forward_pass_matrix(nstates, nsnps); //Initialize the matrix
  NumericVector pi_initial      = rep(1/nstates,nstates); //Get initial probabilities (pi's; uniform)

  //Replace first column in forward pass matrix
  forward_pass_matrix( _ , 0)    = pi_initial;
  for (int k = 0; k < nstates; k++){ //Loop through initial state probabilities
    forward_pass_matrix(k,0) = pi_initial(k) * allele_frequency_matrix(k,0);
  }
  //Normalize the first column of probabilities
  forward_pass_matrix(_,0) = forward_pass_matrix(_,0)/sum(forward_pass_matrix(_,0));

  NumericVector fp0 = forward_pass_matrix(_,0); //Store first column
  for (int t = 0; t < (nsnps-1); t++) { //Loop through the columns (SNPS)
    //Sum the mixed states as well as the averaging factor
    NumericVector fp1 = c + (fp0*a);
    //Now multiply by the observed probability at the length in the sequence
    fp1 = ( c+ (fp0*a)) * allele_frequency_matrix(_,t+1);
    //Normalize and scale the probabilities
    fp0 = fp1/sum(fp1);
    //Store the results
    forward_pass_matrix(_,t+1) = fp0;
  }
  return(forward_pass_matrix);
}

// [[Rcpp::export]]
NumericMatrix subset_update_c(NumericMatrix old_weights,
                              int           idx,
                              NumericVector new_weights){
  //This function will update the matrix (hopefully without copying!)
  old_weights( ( idx - 1 ), _ )    = new_weights;
  return(old_weights);
}

// [[Rcpp::export]]
NumericMatrix normalize_columns(NumericMatrix raw_probabilities){
  int ncol = raw_probabilities.ncol();
  int nrow = raw_probabilities.nrow();
  NumericMatrix norm_prob(nrow,ncol);
  for (int i = 0; i < (ncol); i++) { //Loop through the columns (SNPS)
    norm_prob(_,i) = (raw_probabilities(_,i))/sum(raw_probabilities(_,i));
  }
  return(norm_prob);
}

// [[Rcpp::export]]
NumericMatrix sweep_subtract(NumericMatrix raw_probabilities,
                             NumericVector column_maxs){
  int ncol = raw_probabilities.ncol();
  int nrow = raw_probabilities.nrow();
  NumericMatrix norm_prob(nrow,ncol);
  for (int i = 0; i < (ncol); i++) { //Loop through the columns (SNPS)
    norm_prob(_,i) = (raw_probabilities(_,i)) - column_maxs(i);
  }
  return(norm_prob);
}

