#' @useDynLib InferLD
#' @importFrom Rcpp sourceCpp
NULL
