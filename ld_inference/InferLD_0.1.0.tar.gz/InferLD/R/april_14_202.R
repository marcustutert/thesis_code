# #What we want is a EUR/AFR panel, using only SNPs > 1% MAF
# #Take the SNPs from UKBB at >1% MAF
# #Get intersection of this
# #Prepare inference files, and run inference with this joint panel (chromosome wide)
# 
# 
# bolt_gwas_sumstats      = fread("/well/mcvean/ukbb12788/mtutert/test_genotyped_chr1", header = T)
# #Extract all bolt_gwas_sumstats that > 1% MAF
# SNP_id_ukbb_passed_maf  = bolt_gwas_sumstats[which(bolt_gwas_sumstats$A1FREQ > 0.01 | bolt_gwas_sumstats$A1FREQ < 0.99)]$SNP
# write.table(SNP_id_ukbb_passed_maf,"/well/mcvean/mtutert/thesis_code/thesis_code/ld_inference/ukbb_snps",quote = F, col.names = F, row.names = F)
# #Extract from 1000G AFR and EUR panel
# 
# #Read in the haplotype panel with these SNPs
# AFR_EUR_panel = t(fread("/well/mcvean/mtutert/thesis_code/thesis_code/ld_inference/AFR_EUR_haps.haps", header = F))
# 
# #Read in the SNPs
# SNPs_id_panel = AFR_EUR_panel[2,]
# 
# #Remove SNPs in UKBB panel that aren't in here
# bolt_maf_passed       = bolt_gwas_sumstats[which(bolt_gwas_sumstats$A1FREQ > 0.01 | bolt_gwas_sumstats$A1FREQ < 0.99),]
# bolt_gwas_filtered    = bolt_maf_passed[(which(SNP_id_ukbb_passed_maf %in% SNPs_id_panel)),]
# bolt_gwas_filtered$SE = bolt_gwas_filtered$SE/(0.2201582*(1-0.2201582))^2
# 
# #mbar                        = (2*361381*0.2201582*(1-0.2201582))
# 
# AFR_EUR_panel = AFR_EUR_panel[6:nrow(AFR_EUR_panel),]
# AFR_EUR_panel = `class<-`(AFR_EUR_panel, 'numeric')
# 
# nsnps = 10
# #set.seed(100)
# results                             = LD_from_GSHMM(ref_allele_matrix     = AFR_EUR_panel[,1:nsnps],
#                                                     fst                   = 0.01,
#                                                     alpha                 = 10,
#                                                     nSamples              = 2,
#                                                     weights_resolution    = 10,
#                                                     likelihood_toggle     = TRUE,
#                                                     gwas_variance         = bolt_gwas_filtered$SE[1:nsnps],
#                                                     LD_Infer              = FALSE,
#                                                     recombination         = FALSE,
#                                                     case_control_constant = mbar/2,
#                                                     BurnIn                = 0.9,
#                                                     debug                 = TRUE)
# 
# 
# fig <- plot_ly(data = iris, y = ~results$log_likelihood, x = ~seq(1:length(results$log_likelihood)))
# fig
# 
# 
# fig <- plot_ly(data = iris, x = ~bolt_gwas_filtered$A1FREQ[1:nsnps])
# fig <- fig %>% add_trace(y = ~colMeans(AFR_EUR_panel)[1:nsnps], name = 'trace 0',mode = 'markers')
# fig <- fig %>% add_trace(y = ~rowMeans(results$inferred_af_given_weights[,(.9*length(results$log_likelihood)):length(results$log_likelihood)]), name = 'trace 1', mode = 'markers')
# fig <- fig %>% add_trace(y = ~rowMeans(results$inferred_af_given_weights[,1000:2000]), name = 'trace 1', mode = 'markers')
# fig <- fig %>% add_trace(y =~ seq(0,1,0.01), x=~ seq(0,1,0.01), name = 'trace 1', mode = 'line')
# #summary(lm(rowMeans(results$inferred_af_given_weights[,2000:2324])~bolt_gwas_filtered$A1FREQ[1:nsnps]))$r.squared
# fig
