#' @export
gamma_weight_states <- function(weights_resolution,
                               ref_allele_matrix,
                               fst) {
  #Number of Weights
  nhaps = nrow(ref_allele_matrix)
  
  #Draw weights from the gamma quantile
  gamma_quantiled_weights =  qgamma(p     = (1:weights_resolution) / (1 + weights_resolution),
                                    shape = 1 / ( nhaps * ( fst / (1-fst))),
                                    scale = ( nhaps * (fst/(1-fst))))
  gamma_quantiled_weights = gamma_quantiled_weights[is.finite(gamma_quantiled_weights) & gamma_quantiled_weights > 0 ]
  return(gamma_quantiled_weights)
}

#' @export
weight_update = function(ref_allele_matrix,
                         weight_matrix,
                         gamma_weight_states,
                         row_update){

  nsnps = ncol(ref_allele_matrix)
  nhaps = nrow(ref_allele_matrix)
    #Slow way of updating, assuming we haven't updated yet
    if (row_update < 2) {
    x1_sums            = colSums(weight_matrix*ref_allele_matrix) - (weight_matrix[row_update,] * ref_allele_matrix[row_update,])
    x1_matrix          = matrix(0,nrow =length(gamma_weight_states),ncol =length(x1_sums))

    for (i in 1:length(x1_sums)) {
      x1_matrix[,i]    = x1_sums[i]
    }

    x2                 = outer(gamma_weight_states, ref_allele_matrix[row_update,], FUN ='*')
    B                  = x1_matrix + x2
    S                  = colSums(weight_matrix)-weight_matrix[1,]
    A                  <<- outer(S,gamma_weight_states, FUN='+')
    x1_matrix          <<- as.matrix(replicate(length(gamma_weight_states), x1_sums))
    allele_frequencies = t(x1_matrix)
    allele_frequencies = t(B)/A
    #Return the allele frequencies
    return(allele_frequencies)
  }

  #Incremental update, given that we've already stored some of the totals from above (aka we are on at least the 2nd haplotype being updated!)
  else{
    A_idx_removed           = weight_matrix[row_update,]
    A_idx_minus_one_removed = weight_matrix[(row_update-1),]
    A_weights_differences = A_idx_minus_one_removed - A_idx_removed
    A = sweep(A, 1, A_weights_differences, "+")

    #Incremental updates for x1
    x1_idx_removed                = weight_matrix[(row_update-1),] * ref_allele_matrix[(row_update-1),]
    x1_idx_minus_one_removed      = weight_matrix[row_update,] * ref_allele_matrix[row_update,]

    #We add the previous row (idx-1) and remove the current row weights (idx)
    x1_weights_differences = x1_idx_minus_one_removed - x1_idx_removed

    #Sweep across the column sums, keep this value globally
    x1_matrix = sweep(x1_matrix, 1, x1_weights_differences, "-")
    #Transpose this matrix
    x1_matrix = t(x1_matrix)
    #Incremental updates for x20
    x2        = outer(gamma_weight_states, ref_allele_matrix[row_update,], FUN ='*')

    #Carry out the matrix division with incremental updated matrices to get the allele frequencies
    if (!identical(dim(x1_matrix),dim(x2))) {
      x2 = t(x2)
      B                  = x1_matrix + x2
      allele_frequencies = B/A
    }
    else{
      B                  = x1_matrix + x2
      allele_frequencies = t(B)/A
    }
  }
  return(allele_frequencies)
}

#' @export
constant_weight_sums  = function(weight_matrix,
                                 row_update) {
  nhaps = nrow(weight_matrix)
  if (row_update  == 1) {       #This is edge case where we just finished a full sweep update
    return(colSums(weight_matrix[-c(row_update,nhaps),]))
  }
  return(colSums(weight_matrix[-c(row_update,row_update-1),])) #Sum up the current weight matrix minus current and previously updated weight
}

#' @export
incremental_allele_frequency_update = function(haplotype_minus_update,
                                               weight_matrix,
                                               row_update,
                                               gamma_weight_states,
                                               previous_update,
                                               ref_allele_matrix)
{
  #WIP
  nhaps = nrow(weight_matrix)
  nsnps = ncol(weight_matrix)
  #Take the previous sums from the update (haplotype_minus_update) and then find the difference between that and the current update
  sums_diff     = weight_matrix[(row_update),] - gamma_weight_states[previous_update]
  update_diff   = haplotype_minus_update - sums_diff
  #Create matrix from gamma quantiled weights (with dimensions nstates x nsnps)
  gamma_weights        = matrix(gamma_weight_states, nrow= length(gamma_weight_states), ncol=nsnps, byrow=FALSE)
  updated_weights      = sweep(gamma_weights, 2, update_diff, FUN = "+")
  updated_weights_sums = colSums(updated_weights)
  update_weights_norm  = updated_weights %*% diag(1/updated_weights_sums)
  colSums(weight_matrix_normalized * ref_allele_matrix)

}

#' @export
allele_frequency_update = function(ref_allele_matrix,
                                  weight_matrix,
                                  gamma_weight_states,
                                  row_update){

  nsnps = ncol(ref_allele_matrix)
  nhaps = nrow(ref_allele_matrix)

  allele_frequencies_slow = matrix(data = NA, nrow = length(gamma_weight_states), ncol = nsnps)
  for (i in 1:ncol(allele_frequencies_slow)) {
    weight_matrix_replicated = matrix(weight_matrix[-row_update,i], nrow=length(weight_matrix[-row_update,i]), ncol=length(gamma_weight_states), byrow=TRUE)

    #Add in the new column of quantiles weight states AT THE RIGHT ROW that we have missed
    weight_matrix_modified      = rbind(weight_matrix_replicated[1:(row_update-1),],gamma_weight_states,weight_matrix_replicated[-(1:(row_update-1)),])
    allele_frequencies_slow[,i] = colSums(weight_matrix_modified * ref_allele_matrix[, i]) / colSums(weight_matrix_modified)
  }
  return((allele_frequencies_slow))
}

#' @export
prob_sigma_given_frequency = function(allele_frequency_matrix,
                                      gwas_variance_observed,
                                      noise,
                                      likelihood_toggle,
                                      case_control_constant = 1){
  
  #Turning off Likelihood to test recovery of priors etc
  if (likelihood_toggle == FALSE){
    states = nrow(allele_frequency_matrix)
    snps   = ncol(allele_frequency_matrix)
    prob_normalized = matrix(data = 1/states,nrow = states, ncol = snps)
    return(prob_normalized)
  }
  
  #Sample weights according to our likelihood function
  if (likelihood_toggle == TRUE){
    #Change values of 100% allele frequency to our capped % values
    #het                           = 1
    het                            =  4 * allele_frequency_matrix *(1-allele_frequency_matrix)
    #implied_gwas_variance         = (1/(2*case_control_constant*(allele_frequency_matrix*(1-allele_frequency_matrix))))
    implied_gwas_variance          = (1/(case_control_constant*het/2))
    #Divide each row by the observed GWAS variance
    ratio                          = sweep(implied_gwas_variance, MARGIN = 2, STATS = gwas_variance_observed, `/`)
    log_prob_observed              = (dgamma(ratio, shape = noise * het, scale = 1 / ( noise * het ), log = T ) ) #Keep this in log space
    
    probability_across_states = rowSums(log_prob_observed)
    return((probability_across_states)) #This is in REAL SPACE
    }
}

#' @export
forward_pass = function(allele_frequency_matrix,
                        diag_transition)
{
    #Define a few constants to make notation easier below
    states = nrow(allele_frequency_matrix)
    snps   = ncol(allele_frequency_matrix)
    if (snps > 1) { #Assume we need to do HMM like algorithims
      #Diag_transition gives the value of going from state i->i (let's make it high for now)
      c = (1-diag_transition)/(states-1)
      a = diag_transition - c
      #Create a forward pass matrix, which has dimensions # of gamma quantile states by # of SNPs
      forward_pass_matrix = matrix(nrow = states, ncol= snps)
      pi_initial = rep(1/states,states)
      for(k in 1:states){
        forward_pass_matrix[k,1] = pi_initial[k] * allele_frequency_matrix[k,1]
      }
      #Normalize the first column of probabilities
      forward_pass_matrix[,1] = forward_pass_matrix[,1]/sum(forward_pass_matrix[,1])
      fp0 = forward_pass_matrix[,1]
      for(t in 1:(snps-1)){
        #Sum the mixed states as well as the averaging factor
        #fp1 = c+ (fp0*a)
        #Now multiply by the observed probability at the length in the sequence
        fp1 = (( c+ (fp0*a))) * (allele_frequency_matrix[,t+1])
        #fp1_max  = max(fp1)
        #fp1_norm = fp1 - fp1_max
        #fp1_real = exp(fp1)
        #Normalize and scale the probabilities
        #fp1_real[is.nan(fp1_real)] <- 0
        #fp1_real[fp1_real == 0] = 1e-20
        fp0      = fp1/sum(fp1)
        forward_pass_matrix[,t+1] = fp0
      }
    }
  else{
    forward_pass_matrix = allele_frequency_matrix
  }
    if (any(is.nan(forward_pass_matrix))) {
      }
  return(forward_pass_matrix)
}

#' @export
sample_HMM_path = function(forward_pass_matrix,
                           diag_transition,
                           j,
                           row_update,
                           weight_matrix,
                           gamma_quantiled_weights,
                           genetic_map,
                           recombination){

    #Writing a function that samples a single path backwards through the forward algorithm matrix posteriors
    #Define a few constants to make notation easier below
    states      = nrow(forward_pass_matrix)
    snps        = ncol(forward_pass_matrix)
    recomb_rate = 1 - diag_transition #This is a vector of length nsnps-1
    path        = rep(NA,snps)        #Initialize path trace vector

    if (recombination == FALSE) {
      #In this case we simply would need to sample a single time and then this will be our new path
      if (any(is.na(forward_pass_matrix[,snps]))) {
      }
      path[1:snps] = sample( x = 1:states, size = 1, prob =  forward_pass_matrix[,snps])
    }
    else{
    if ( snps > 1 ) {
      if (genetic_map == TRUE) {

        state_switch_transition = (1 - diag_transition) / ( states - 1 )
        #Start with last column, pick the state that we will be starting in
        path[snps] = sample( x = 1:states, size = 1, prob =  forward_pass_matrix[,snps]/sum(forward_pass_matrix[,snps]))
        #Now loop back through all the columns to get the full backtrace
        for (i in rev(seq(snps:1))[-length(snps)]) {
          a_ij            = rep(state_switch_transition[i],nrow(forward_pass_matrix))
          a_ij[path[i+1]] = diag_transition
          probabilities   = a_ij * forward_pass_matrix[,i]
          probabilities   = probabilities/sum(probabilities)
          path[i] = sample( x = 1:states, size = 1, prob = probabilities)
        }
      }
      if (genetic_map == FALSE)
      {
        #Sqmple the first state going backwards.
        prob        = forward_pass_matrix[,snps]
        path[snps]  = sample( x = 1:states, size = 1, prob =  forward_pass_matrix[,snps])
        #While loop will keep moving backwards until we have filled up path with numbers and have no more NA's
        while (any(is.na(path)) == TRUE) {

          #Generate probability from uniform distribution
          prob = runif(n = 1, min = 0, max = 1)

          #Store the position of the first non NA value in our path vector
          NonNAindex <- which(!is.na(path))
          firstNonNA <- min(NonNAindex) #This tells us where on our path we have gotten to trace-wise

          #Subset the forward pass matrix given what last state we are in the trace, we want that full state row back in time
          forward_matrix_subset_state = forward_pass_matrix[path[firstNonNA],(firstNonNA-1):1]

          #Calculate digammas and generate one for each possible jump (k of these digammas)
          digamma_vector = ((forward_matrix_subset_state * (1-recomb_rate))/(recomb_rate/(states-1)+forward_matrix_subset_state*(1-(states*recomb_rate/(states-1)))))

          #Use exp(cumsum(log(digamma_k))) trick to get CDF
          #p_k gives us our CDF probability values for moving given we haven't moved yet!
          p_k             = 1-exp(cumsum(log(digamma_vector)))
          switch_position = which.max((p_k-prob)) - 1

          #Find the switch position by looking up nearest value of our probability in our CDF vector
          if( prob > max( p_k ) | sum(is.na(path)) < switch_position ) {
            path[1:(firstNonNA-1)] = rep(path[firstNonNA],firstNonNA-1) } #Stay in the same state all the way back
          else
          {
            #If we switch right away we need to consider this condition
            if (switch_position == 0) {
              state_prob = forward_pass_matrix[-path[firstNonNA],firstNonNA-switch_position]/sum(forward_pass_matrix[-path[firstNonNA],firstNonNA-switch_position])
              if(any(is.na(state_prob))){
                state_prob = rep(1/(states-1),states-1)}
              #Then we want to move to a new state after this and repeat
              path[firstNonNA-1] = sample( x = (1:states)[-path[firstNonNA]], size = 1, prob = state_prob)
            }
            else
            {
              #We want to repeat the last traced path state, a 'switch number' of times
              path[(firstNonNA-switch_position):(firstNonNA-1)] = rep(path[firstNonNA], switch_position)
              #We also want to remove the chance of being in the same state as a possibility (since we are going from i->j)
              state_prob = forward_pass_matrix[-path[firstNonNA],firstNonNA-switch_position]/sum(forward_pass_matrix[-path[firstNonNA],firstNonNA-switch_position])
              #Then we want to move to a new state after this and repeat
            }
          }
        }
      }
    }
  else{ #This is if we have only one SNP to consider (no need to do this sampling trick)
    path = sample( x = (1:states), size = 1, prob = forward_pass_matrix )
    }
  }
  #Return our path vector at the end
  return(path)
}

#' @export
#Create a function that actually does the Gibbs Sampling (We will need something like this to perform the incremental updates)
#We want to return  the Gibbs implied allele frequency matrices
Allele_Freq_Check = function(recomb_rate, nSamples, weights_resolution, ref_allele_matrix, fst, observed_sigma_b, alpha){

  #Get the nsnps and nhaps from ref_allele_matrix
  nsnps = ncol(ref_allele_matrix)
  nhaps = nrow(ref_allele_matrix)

  #Generate the Gamma Quantiled Weight Space
  gamma_quantiled_weights = gamma_weight_states(weights_resolution = weights_resolution, ref_allele_matrix = ref_allele_matrix, fst = fst)

  #Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to nhaps)
  #constant_weight = gamma_quantiled_weights[sample(x = 1:length(gamma_quantiled_weights),size = 1,replace = TRUE,prob = NULL)]
  #weight_matrix   = matrix(data = constant_weight, nrow = nhaps, ncol = nsnps)
  weight_matrix = matrix( sample(gamma_quantiled_weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps, byrow = TRUE )

  #Initialize the Gibbs Matrices
  Gibbs_Allele_Freq        = matrix(data = NA, nrow = nsnps, ncol = nSamples)
  weights_matrix_sum       = colSums(weight_matrix)
  if (length(weight_matrix_sum) == 1) {
    weight_matrix_normalized    = weight_matrix/weight_matrix_sum
  }
  else{
    weight_matrix_normalized      = weight_matrix %*% diag(1/weight_matrix_sum)
  }
  Gibbs_Allele_Freq[,1]           = colSums(ref_allele_matrix*weight_matrix_normalized)

  for (j in 2:nSamples) {
    #cat( sprintf("\r%d", j))
    for (idx in 1:nhaps){

      weight_increment = allele_frequency_update(ref_allele_matrix = ref_allele_matrix, weight_matrix = weight_matrix, gamma_weight_states = gamma_quantiled_weights, row_update = idx)
      #Use the function for prob given the implied sigma_b
      #Get the forward pass through this matrix
      forward_pass_matrix   = forward_pass(allele_frequency_matrix = prob_normalized, diag_transition = 1-recomb_rate)
      path                  =  sample_HMM_path(forward_pass_matrix = forward_pass_matrix, diag_transition = 1-recomb_rate)
      # #Pick out the correct weights, given the path states, path is a vector
      weight_matrix[idx,] = gamma_quantiled_weights[path]
    }
    #Get the sample averages for the allele frequencies
    weights_matrix_sum       = colSums(weight_matrix)
    if (length(weight_matrix_sum) == 1) {
      weight_matrix_normalized    = weight_matrix/weight_matrix_sum
    }
    else{
      weight_matrix_normalized      = weight_matrix %*% diag(1/weight_matrix_sum)
    }
    Gibbs_Allele_Freq[,j]    = colSums(ref_allele_matrix*weight_matrix_normalized)
  }

  #Return the matrix for the calculation of the Gibbs implied allele frequencies
  return(Gibbs_Allele_Freq)
}

#' @export
incremental_weight_update = function(ref_allele_matrix,          #Reference allele panel
                                     current_update_weights,     #The current weights (after choosing the weights given some probability)
                                     gamma_weight_states,        #All nstates gamma weights (from the prior)
                                     current_haplotype_update){  #Which weight index are we replacing
  
  nsnps            = ncol(ref_allele_matrix)
  nstates          = length(gamma_weight_states)
  nhaps            = nrow(ref_allele_matrix)
  
  results          = matrix(data = NA, ncol = nsnps, nrow = nstates)
  m                = colSums(current_update_weights * ref_allele_matrix) 
  
  #Vectorized way of getting the incremental allele frequencies
  diff_weights_across_states = gamma_weight_states - current_update_weights[current_haplotype_update]
  #Weighted difference for current update
  weighted_diff              = outer(diff_weights_across_states,ref_allele_matrix[current_haplotype_update,])
  allele_frequencies         = t((t(weighted_diff) + m))/(sum(current_update_weights) + gamma_weight_states - current_update_weights[current_haplotype_update])
  
  # for(i in 1:(nstates)){
  #   browser()
  #   diff_val       = gamma_weight_states[i] - current_update_weights[current_haplotype_update]
  #   #Multiply that by the row we changed
  #   diff_m         = t(as.matrix(diff_val * ref_allele_matrix[current_haplotype_update,]))
  #   x              = (diff_m + m)/((sum(current_update_weights) + gamma_weight_states[i] - current_update_weights[current_haplotype_update]))
  #   results[i,]    = x
  # }
  allele_frequencies[allele_frequencies > 0.99] = 0.99
  allele_frequencies[allele_frequencies < 0.01] = 0.01
  return(allele_frequencies)
}

#' @export
gibbs_sampler           = function(nSamples,              #Total number of full loops through reference panel
                                   weights_resolution,    #Number of weight states
                                   ref_allele_matrix,     #Reference allele matrix dim:(nhaps,nsnps)
                                   fst,                   #Genetic Drift
                                   gwas_variance,         #Observed GWAS standard errors^2
                                   alpha,                 #Noise term
                                   likelihood_toggle,     #Turn off/on likelihood
                                   debug,                 #If TRUE output the liklihood curve and allele frequencies over time
                                   recombination,         #If TRUE run version under HMM (weights changing along genome); flip to a matrix version
                                   case_control_constant) #Default set to one (under generative model)
{

  ref_allele_matrix = as.matrix(ref_allele_matrix) #Convert to matrix, just in case
  #Get parameters
  nsnps   = ncol(ref_allele_matrix)
  nhaps   = nrow(ref_allele_matrix)
  nstates = weights_resolution
  
  #Calculate number of individual updates
  total_updates = nSamples*nhaps-nhaps

  #Store the weight results
  if (recombination == FALSE) {
    #With no-recombination, there will be a single weight across each of the nhaps, for each individual sample ie: a matrix
    gibbs_matrix = matrix(data = NA, nrow = nhaps,ncol = total_updates + 1)
  }

  #Generate the Gamma Prior under given level of Fst
  gamma_quantiled_weights = gamma_weight_states(weights_resolution = weights_resolution,
                                                ref_allele_matrix  = ref_allele_matrix,
                                                fst                = fst)

  #Redefine weights length based on if we had NAs in previous step
  #Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to nhaps)
  initial_weights = sample(x = gamma_quantiled_weights, size = nhaps, replace = TRUE)

  #Store results in first column of Gibbs Array (these will be the weights)
  #gibbs_matrix[,1] = initial_weights
  
  #Or if we want to start from the reference panel, then we fill first column with the same value (equivalent to 1/nhaps)
  gibbs_matrix[,1]               = initial_weights[1]

  #Let us also keep track of the likelihoods for debugging purposes downstream
  log_likelihood                  =  c()
  inferred_af_given_weights       = matrix(data = NA, nrow = nsnps, ncol = total_updates + 1)
  #Normalise weights
  normalised_weights              = gibbs_matrix[,1]/sum(gibbs_matrix[,1])
  #Calculate the allele frequencies
  inferred_af_given_weights[,1]   = colSums(normalised_weights * ref_allele_matrix)
  het                             = 4 * inferred_af_given_weights[,1] *(1-inferred_af_given_weights[,1])
  implied_gwas_variance           = 1/(2*case_control_constant*(inferred_af_given_weights[,1]*(1-inferred_af_given_weights[,1])))
  ratio                           = gwas_variance / implied_gwas_variance
  log_likelihood[1]               = sum(dgamma(ratio, shape=alpha*het, rate=alpha*het, log=T)) #Sum across all variants (log likelihood)
  counter = 1
  #Loop through the next full nSamples through the reference panel
  for (j in 2:nSamples) {
    oo = sample(nhaps)
    #Loop randomly through the haplotypes
    for (idx in 1:nhaps)  {
      flush.console()
      #Keep count of where in the MCMC sampler we are
      cat( sprintf("\r MCM Sampling %f Percentage Done", (counter)/((nSamples-1)*nhaps -1)*100))
      idx = oo[idx]
      
      #Split up into either recombination or no recombination case
      if (recombination == FALSE) {
        #if (length(log_likelihood) == 267){browser()}
        #Function will take in the previous weights, and incrementally update them
        weight_increment = incremental_weight_update(ref_allele_matrix            = ref_allele_matrix,                                     
                                                     current_update_weights       = gibbs_matrix[,counter],
                                                     gamma_weight_states          = gamma_quantiled_weights,        
                                                     current_haplotype_update     = idx)

       #Calculate probabilites across the states and SNPs
       log_probability_across_states = prob_sigma_given_frequency(allele_frequency_matrix = weight_increment,
                                                    gwas_variance_observed  = gwas_variance,
                                                    noise                   = alpha,
                                                    likelihood_toggle       = likelihood_toggle,
                                                    case_control_constant   = case_control_constant)
       
       probability_across_states = exp(log_probability_across_states - max(log_probability_across_states))/(sum(exp(log_probability_across_states - max(log_probability_across_states))))
       new_state = sample(x = seq(1:length(gamma_quantiled_weights)), size = 1,replace = FALSE, prob = probability_across_states)
       
       #Replace in the next column of the gibbs matrix
       gibbs_matrix[,counter+1]    =  gibbs_matrix[,counter]
       gibbs_matrix[idx,counter+1] =  gamma_quantiled_weights[new_state]
      #Calculate likelihood, if we are debugging
      if (debug == TRUE) {
        #Take the likelihood from the value from log_probability_across_states
        log_likelihood[counter]                = log_probability_across_states[new_state]
        #Extract the value from weight_increment of the allele frequencies
        inferred_af_given_weights[,counter+1]  = weight_increment[new_state,]       
        counter                                = counter + 1 #Update counter
      }
     }
   }
  }
  #Return the matrix for the calculation of the Gibbs implied allele frequencies
  list_results = list(gibbs_matrix,
                      log_likelihood,
                      inferred_af_given_weights)
  #Name the elements in the list
  names(list_results) <- c("Gibbs_Array",
                           "log_likelihood",
                           "inferred_af_given_weights")
  return(list_results)
}

#' @export
find_recomb_hotspots = function(recomb_events,
                                moving_avg_window = 5,
                                recomb_threshold  = 3){
  #This function will take in a list of recombination events (scaled?) from the weight inference process
  #Outputs a list of recombination hotspots (as a matrix (start:end))
  #Recomb events is a matrix of dimensions (nhaps x nsnps x nSamples (post burnIn))
  nsnps    = dim(recomb_events)[2]
  nhaps    = dim(recomb_events)[1]
  nSamples = dim(recomb_events)[3]

  #Now we want to average out the number of events across the nhaps
  recomb_events_haps = colSums(recomb_events,
                               na.rm = TRUE,
                               dims = c(1))
  recomb_events_avg  = rowMeans(recomb_events_haps)

  #Now we can tak this and look at the rolling average across the region of recomb. events
  moving_avg_recomb    <- function(x, n = moving_avg_window){filter(x, rep(1 / n, n), sides = 2)}
  recomb_events_mov_avg = moving_avg_recomb(recomb_events_avg, n = moving_avg_window)

  #Now that we have the smoothed regression line, we are interested in finding where the peaks are
  #Easiest thing to do is just find whenever recomb hotspots > some number
  recomb_above_thresh  = which(recomb_events_mov_avg > 3)
  recomb_hotspots_list = split(recomb_above_thresh, cumsum(c(1, diff(recomb_above_thresh) != 1)))
  return(recomb_hotspots_list)
}

#This function will take in some genetic map (from 1000G) and output a new list of the recombination rate which will then be used to
#Match the transition rates within the HMM
#' @export
genetic_map_hotspots = function(genetic_map,
                                average_window   = 5,
                                hotspot_rate_min = 5, #How high does a hot-spot need to be considered one
                                start_position,
                                end_position,
                                nhaps_reference  = 1000,#
                                directory){
  moving_avg_recomb    <- function(x, n = moving_avg_window){filter(x, rep(1 / n, n), sides = 2)}
  start_index            = which.min(abs(genetic_map$position-start_position)) -1
  end_index              = which.min(abs(genetic_map$position-end_position)) + 1 #Add one to go over
  recomb_events_mov_avg  = moving_avg_recomb(genetic_map$COMBINED_rate.cM.Mb.[(start_index):(end_index)], n = average_window)
  recomb_scaled_hotspots = replace(recomb_events_mov_avg, recomb_events_mov_avg < 5,0)
  transition_rates       = rep(NA,length(genetic_map$position[(start_index-1):(end_index+1)]))
  transition_rates[which(recomb_scaled_hotspots == 0)] = 1e-100   #Coldspots
  transition_rates[which(recomb_scaled_hotspots > 0)]  = recomb_scaled_hotspots[which(recomb_scaled_hotspots > 0)]/nhaps_reference

  #If any NA's remain around edges, replace with the recomb rate rate besides it (bootstrap later)
  transition_rates           = na.locf(transition_rates)
  bp                         = genetic_map$position[(start_index):(end_index)]
  print(transition_rates)
  transition_rates           = as.matrix(transition_rates)
  rownames(transition_rates) = bp
  return(transition_rates)
}

transition_rates_genetic_map = function(transition_rates, #List of recombination rates by BP
                                        ref_panel,
                                        start_position,
                                        end_position,
                                        directory){       #Variants in our file
  bp               = as.numeric(colnames(ref_panel))
  print(bp)
  nsnps            = ncol(ref_panel)
  scaled_avg       = c()
  transition_rates = cbind(as.matrix(transition_rates),rownames(transition_rates))
  transition_rates = `class<-`(transition_rates, 'numeric')
  scaled_avg       = rep(NA,(nsnps))

  for (i in 1:(nsnps-3)) {
    leftward_recomb_index        = findInterval(bp[i],transition_rates[,2])
    rightward_recomb_index       = findInterval(bp[i],transition_rates[,2])+1
    distance_left_recomb_to_snp  = bp[i]-transition_rates[leftward_recomb_index,2]
    distance_right_recomb_to_snp = transition_rates[rightward_recomb_index,2] - bp[i]
    total_distance_breakpoints   = transition_rates[rightward_recomb_index,2]-transition_rates[leftward_recomb_index,2]

    if (transition_rates[leftward_recomb_index,2] == bp[i]) {
      scaled_avg[i] = unlist((transition_rates[leftward_recomb_index,1]))
    }
    if (transition_rates[rightward_recomb_index,2] != bp[i] & transition_rates[leftward_recomb_index,2] != bp[i] ){
      scaled_avg[i]    = unlist(transition_rates[leftward_recomb_index] + distance_left_recomb_to_snp/total_distance_breakpoints * (transition_rates[rightward_recomb_index]-transition_rates[leftward_recomb_index]))
    }
  }
  scaled_avg = na.locf(scaled_avg)
  write.table(scaled_avg,file = sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s/hmm_recomb_map",directory),
              quote     = FALSE,
              row.names = FALSE,
              col.names = FALSE)
  return(scaled_avg)
}
