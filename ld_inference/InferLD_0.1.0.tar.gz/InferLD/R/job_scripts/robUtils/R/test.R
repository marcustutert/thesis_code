if( !exists( "testEnv" ) )
{
  testEnv = new.env()
  assign( "testCount", 0, envir = testEnv )
}

##################################################################/
# Name:        utils.test.start
# Description: reset at astart of a test
###################################################################/
utils.test.start = function()
{
  assign( "testCount", 0, envir = testEnv )
}

##################################################################/
# Name:        utils.test.test_that
# Description: wrapper around test_that
###################################################################/
utils.test.test_that = function( message, code )
{
  # increment counter
  count = get( "testCount", envir = testEnv )
  count = count + 1;
  assign( "testCount", count, envir = testEnv )

  # log test
  utils.log( sprintf( "TEST %d: %s\n", count, message ) )

  # run test
  test_that( message, code )
}
