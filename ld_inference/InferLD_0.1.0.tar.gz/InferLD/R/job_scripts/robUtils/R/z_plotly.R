###################################################################/
# utils.plotly.scatter.class ####
###################################################################/
utils.plotly.scatter.class = utils.class(
  classname = "utils.plotly.scatter.class",
  inherit = utils.shiny.element,
  public = list(
    ###################################################################################/
    # initialize
    ###################################################################################/
    initialize = function( ui = NULL, server = NULL , callBacks = list(), reactiveValues = list() )
    {
      super$initialize( ui = ui, server = server, callBacks = callBacks, reactiveValues = reactiveValues )
    },
    ###################################################################################/
    # update
    ###################################################################################/
    update = function()
    {
      self$setRV( "update", self$getRV( "update" ) + 1 )
    }
  ),
  active = list(
    ###################################################################################/
    #  data
    ###################################################################################/
    data = function( data )
    {
      if( missing( data ) )
        return( self$getRV( "data") )
      else
      {
        self$setRV( "data", data )
        self$update()
      }
    }
  )
)

###################################################################/
# utils.genomicPoint.class ####
###################################################################/
utils.genomicPoint.class = utils.class(
  classname  = "utils.genomicPoint.class",
  public     = list(
    chrom = "",
    pos   = 0,
    initialize = function( chrom, pos ) { self$chrom = chrom; self$pos = pos }
  )
)

###################################################################/
# utils.genomicRange.class ####
###################################################################/
utils.genomicRange.class = utils.class(
  classname  = "utils.genomicRange.class",
  public     = list(
    chrom  = "",
    posMin = 0,
    posMax = 0,
    initialize = function( chrom, posMin, posMax ) { self$chrom = chrom; self$posMin = posMin; self$posMax = posMax }
  )
)

###################################################################/
# utils.plotly.genomic.interface ####
###################################################################/
utils.plotly.genomic.interface = utils.class.interface(
  interfacename = "utils.plotly.genomic.interface",
  active        = list(
    chrom    = function() return(),
    pos      = function() return(),
    chromCol = function() return(),
    posCol   = function() return()
  ),
  public = list(
    update             = function() return(),
    addCallBackGenomic = function() return()
  )
)

###################################################################/
# utils.plotly.scatter.genomic.class ####
###################################################################/
utils.plotly.scatter.genomic.class = utils.class(
  classname  = "utils.plotly.scatter.genomic.class",
  inherit    = utils.plotly.scatter.class,
  interfaces = list( utils.plotly.genomic.interface ),

  ###################################################################################/
  # private variables to record where genomic data is
  ###################################################################################/
  private = list(
    .chromCol = NULL,
    .posCol   = NULL,
    .chrom    = "chr1",
    .pos      = 1,
    .colorGenomicDist = NULL
  ),

  public = list(
    ###################################################################################/
    # update
    ###################################################################################/
    update = function( genomicPos = NULL )
    {
      if( !is.null( genomicPos ) )
      {
        if( inherits( genomicPos, "utils.genomicPoint.class" ) )
        {
          self$chrom = genomicPos$chrom
          self$pos   = genomicPos$pos
        }
        else
        if( inherits( genomicPos, "utils.genomicRange.class" ) )
        {
          self$chrom = genomicPos$chrom
          posMin     = genomicPos$posMin
          posMax     = genomicPos$posMax
          if( !is.null( posMin ) & !is.null( posMax ) )
            if( !is.na( posMin ) & !is.na( posMax ) )
              self$pos = ( posMin + posMax ) / 2
        }
        else
          utils.throw( "can only accept a genomicRange or genomicPoint" )
      }

      data = self$data
      .colorGenomicDist( data, self$colorGenomicDist, .colorGenomicDistCol, self$chromCol, self$chrom, self$posCol, self$pos )
      self$setRV( "data", data )
      super$update()
    },

    ###################################################################################/
    # addCallBackGenomic
    ###################################################################################/
    addCallBackGenomic = function( obj )
    {
      cb = function( point )
      {
        p = utils.genomicPoint.class$new( chrom = point[ 1, get( self$chromCol ) ], pos = point[ 1, get( self$posCol ) ] )
        obj$update( p )
      }
      self$callBacks$addOnPointSelectedCallBack( cb )
    }
  ),

  ###################################################################################/
  # set and get where genomic data is stored
  ###################################################################################/
  active = list(
    ###################################################################################/
    # chromCol
    ###################################################################################/
    chromCol = function( col )
    {
      if( missing( col ) )
        return( private$.chromCol )

      private$.chromCol = col
    },

    ###################################################################################/
    # posCol
    ###################################################################################/
    posCol = function( col )
    {
      if( missing( col ) )
        return( private$.posCol )
      private$.posCol = col
    },

    ###################################################################################/
    # colorGenomicDist
    ###################################################################################/
    colorGenomicDist = function( dist )
    {
      if( missing( dist ) )
        return( private$.colorGenomicDist )

      private$.colorGenomicDist = dist
    },

    ###################################################################################/
    # chrom
    ###################################################################################/
    chrom = function( chrom )
    {
      if( missing( chrom ) )
        return( private$.chrom )
      private$.chrom = chrom

    },

    ###################################################################################/
    # pos
    ###################################################################################/
    pos = function( pos )
    {
      if( missing( pos ) )
        return( private$.pos )

      private$.pos = pos
    }
  )
)

###################################################################/
# utils.plotly.scatter ####
###################################################################/
utils.plotly.scatter = function(
  # which data to display
  data,
  columns,
  colorCol = NULL,
  textCol  = NULL,

  # beautification
  xAxisTitle    = "x",
  yAxisTitle    = "y",
  colorBarTitle = NULL,
  mode          = "markers",
  xLabelFunc    = NULL,

  # extensions to allow more complicated graphs
  chartClass = utils.plotly.scatter.class,
  extraRVs   = list(),

  # data control
  copyData = TRUE
)
{
  # unique ID for this this particular plot
  chartId = UUIDgenerate()
  dummyId = sprintf( "%s_dummy", chartId )

  # if more than 2 columns specified then add column selectors to graph
  if( length( columns ) < 2 )
    utils.throw( "must specify at least 2 columns")
  else
  if( length( columns ) == 2 )
  {
    # no frills layout
    ui = fluidPage(
      plotlyOutput( chartId ),
      htmlOutput( dummyId )
    )
  }
  else
  {
    # layout with column selectors
    xInputId = sprintf( "%s_xInput", dummyId )
    xInput   = selectInput(
      inputId = xInputId,
      label   = "x-axis",
      choices = columns,
      width = "100%",
      selected = columns[ 1 ]
    )
    yInputId = sprintf( "%s_yInput", dummyId )
    yInput   = selectInput(
      inputId = yInputId,
      label   = "y-axis",
      choices = columns,
      width = "100%",
      selected = columns[ 2 ]
    )

    ui =fluidPage(
      div( style = "height: 60px", fillRow(  column( 12, xInput ), column( 12, yInput ) ) ),
      fluidRow( column( width = 12, plotlyOutput( chartId ) ) ),
      fluidRow( column( width = 12, htmlOutput( dummyId ) ) )
    )
  }

  # set up ability to add callbacks
  setUpEnv        = environment();
  onPointSelected = list();
  addOnPointSelectedCallBack = function( callBack )
  {
    onPointSelected = get( "onPointSelected", envir =  setUpEnv )
    onPointSelected[[ length( onPointSelected ) + 1 ]] = callBack;
    assign( "onPointSelected", onPointSelected, envir = setUpEnv )
  }

  onRelayout = list();
  addOnRelayoutCallBack = function( callBack )
  {
    onRelayout = get( "onRelayout", envir =  setUpEnv )
    onRelayout[[ length( onRelayout ) + 1 ]] = callBack;
    assign( "onRelayout", onRelayout, envir = setUpEnv )
  }

  # reactive values
  getRV <- function( name )
  {
    RV =  get( "RV", envir =  setUpEnv )
    return( RV[[ name ]] )
  }
  setRV <- function( name, value )
  {
    RV = get( "RV", envir =  setUpEnv )
    RV[[ name ]] = value;
  }

  # update old is a non-reactivevalue which we use to keep track of updates
  assign( "updateOld", 0, envir = setUpEnv );
  assign( "eventOld", list( x = 0 ), envir = setUpEnv );

  # copy of data for chart and add index
  if( copyData )
    DATA = copy( data )
  else
    DATA = data

  # is the data shown in the plot
  if( !utils.data.table.containsColumns( DATA, "INTERNAL_SHINY_SHOW" ) )
    DATA[ , INTERNAL_SHINY_SHOW := TRUE ]

  # get the data range
  xcol = columns[ 1 ]
  XMIN = DATA[ , min( get( xcol ) ) ]
  XMAX = DATA[ , max( get( xcol ) ) ]

  # the basic plot
  getPlot = function( DATA, xCol, yCol, xmin, xmax, ymin, ymax )
  {
    # add index to data to uniquely label points
    DATA[ , INTERNAL_SHINY_INDEX := 1:data[ ,.N ] ]

    # set up colour columns
    if( is.null( colorCol) )
      DATA[ , INTERNAL_SHINY_COLOR := "" ]
    else
      DATA[ , INTERNAL_SHINY_COLOR := get( colorCol ) ]

    # set up colour columns
    if( is.null( textCol) )
      DATA[ , INTERNAL_SHINY_TEXT := "" ]
    else
      DATA[ , INTERNAL_SHINY_TEXT := get( textCol ) ]

    # store copy of decorated data
    assign( "data", DATA, envir = setUpEnv );

    # set up marker details
    if( is.null( colorBarTitle ) | mode != "markers")
      marker = list()
    else
      marker = list( colorbar = list( title = colorBarTitle ) )

    # details of the axis
    xaxis = list( title = xAxisTitle, range = list( xmin, xmax ) )
    yaxis = list( title = yAxisTitle, range = list( ymin, ymax ) )
    if( !is.null( xLabelFunc ) )
    {
      xaxis$tickmode = "array"
      if( is.null( xmin ) )
        xaxis = c( xaxis, xLabelFunc( XMIN, XMAX ) )
      else
        xaxis = c( xaxis, xLabelFunc( xmin, xmax ) )
    }

    # generate the plot
    plot = plot_ly(
      DATA[ INTERNAL_SHINY_SHOW == TRUE ],
      x     = ~get( xCol ),
      y     = ~get( yCol ),
      color = ~INTERNAL_SHINY_COLOR,
      key   = ~INTERNAL_SHINY_INDEX,
      text  = ~INTERNAL_SHINY_TEXT,
      source = chartId,
      marker = marker,
      type = "scatter",
      mode = mode
    ) %>%
      layout(
        plot,
        xaxis = xaxis,
        yaxis = yaxis
      )
    return( plot )
  }

  server = function( input, output )
  {
    assign( "RV", reactiveValues( data = DATA, update = 0, xmin = NULL, xmax = NULL, ymin = NULL, ymax = NULL ), envir = setUpEnv );

    output[[ chartId ]] <- renderPlotly(
      {
        # dummy call to update to force update
        update = getRV( "update" )

        # get columns
        xaxis = ifelse( length( columns ) > 2, input[[ xInputId ]], columns[ 1 ] )
        yaxis = ifelse( length( columns ) > 2, input[[ yInputId ]], columns[ 2 ] )

        getPlot( getRV( "data" ), xaxis, yaxis, getRV( "xmin" ), getRV( "xmax" ), getRV( "ymin" ), getRV( "ymax" )  )
      } )

    output[[ dummyId ]] <- renderText(
      {
        # trigger callbacks on update
        update    =  getRV( "update" )
        updateOld =  get( "updateOld", envir =  setUpEnv )

        events      = list( event_data( "plotly_click", source = chartId ), event_data( "plotly_relayout", source = chartId ) )
        latestEvent = utils.shiny.getLastEvent( events, chartId )
        eventOld    =  get( "eventOld", envir =  setUpEnv )

        if( update != updateOld | is.null( latestEvent ) )
          assign( "updateOld", update, envir = setUpEnv )
        else
        if( utils.list.namedListToChar( latestEvent ) != utils.list.namedListToChar( eventOld ) )
        {
          assign( "eventOld", latestEvent, envir = setUpEnv )
          if( latestEvent$index == 1 )
          {
            latestClick = latestEvent$event
            # run any callbacks if necessary
            if( !is.null( latestClick ) )
            {
              pointSelect = latestClick[ 1, "key" ]
              DATA        = get( "data", envir = setUpEnv )
              rowData     = DATA[ INTERNAL_SHINY_INDEX == pointSelect ]

              onPointSelected = get( "onPointSelected", envir =  setUpEnv )
              if( length( onPointSelected ) )
                for( i in 1:length( onPointSelected) )
                  onPointSelected[[ i ]]( rowData )
            }
          }
          else
            if( latestEvent$index == 2 )
            {
              # deal with layout changes, since we are constantly redrawing then need to remember the last size
              latestLayout = latestEvent$event

              xmin = NA
              xmax = NA
              ymin = NA
              ymax = NA
              if( !is.null( latestLayout$'xaxis.range[0]'))
              {
                xmin = latestLayout$'xaxis.range[0]'
                setRV( "xmin", xmin )
              }
              if( !is.null( latestLayout$'xaxis.range[1]'))
              {
                xmax = latestLayout$'xaxis.range[1]'
                setRV( "xmax", xmax )
              }
              if( !is.null( latestLayout$'yaxis.range[0]'))
              {
                ymin = latestLayout$'yaxis.range[0]'
                setRV( "ymin", ymin )
              }
              if( !is.null( latestLayout$'yaxis.range[1]'))
              {
                ymax = latestLayout$'yaxis.range[1]'
                setRV( "ymax", ymax )
              }
              if( !is.null( latestLayout$'xaxis.autorange' ) )
              {
                xmin = xmax = NULL
                setRV( "xmin", NULL )
                setRV( "xmax", NULL )
              }
              if( !is.null( latestLayout$'yaxis.autorange' ) )
              {
                ymin = ymax = NULL
                setRV( "ymin", NULL )
                setRV( "ymax", NULL )
              }

              onRelayout = get( "onRelayout", envir =  setUpEnv )
              if( length( onRelayout ) )
                for( i in 1:length( onRelayout ) )
                  onRelayout[[ i ]]( xmin, xmax, ymin, ymax )
            }
        }
        ""
      } )
  }

  return( chartClass$new( server = server, ui = ui, callBacks = list( addOnPointSelectedCallBack = addOnPointSelectedCallBack, addOnRelayoutCallBack = addOnRelayoutCallBack ), list( getRV = getRV, setRV = setRV ) ) )
}

.colorGenomicDistCol = "INTERNAL_SHINY_COLOR_GENOMIC"
###################################################################/
# Name:.colorGenomicDist
###################################################################/
.colorGenomicDist = function( data, INTERNAL_COLORGENOMICDIST, colorCol, chromCol, INTERNAL_CHROM_VAL, posCol, INTERNAL_POS_VAL )
{
  data[ , c( colorCol ) := list( ifelse( get( chromCol ) == INTERNAL_CHROM_VAL, pmin( abs( get( posCol ) - INTERNAL_POS_VAL ), INTERNAL_COLORGENOMICDIST ), INTERNAL_COLORGENOMICDIST ) )]
  setorderv( data, c( colorCol ), -1 )
}

###################################################################/
# utils.plotly.scatter.genomic ####
###################################################################/
utils.plotly.scatter.genomic = function(
  data,
  columns,
  xAxisTitle = "x",
  yAxisTitle = "y",
  chromCol   = "chrom",
  posCol     = "chromMid",
  colorCol   = NULL,
  textCol    = NULL,
  colorGenomicDist = NULL,
  initialChrom     = data[ 1, get( chromCol ) ],
  initialPos       = data[ 1, get( posCol ) ],
  copyData         = TRUE
)
{
  if( !is.null( colorCol ) & !is.null( colorGenomicDist) )
    utils.throw( "you can only specify colorCol or set coloring based on genomic distance" )

  if( !utils.data.table.containsColumns( data, c( chromCol, posCol ) ) )
    utils.throw( sprintf( "data must contains %s (chromCol) and %s (posCol)", chromCol, posCol ) )

  if( !is.null( colorGenomicDist ) )
  {
    colorCol = .colorGenomicDistCol
    .colorGenomicDist( data, colorGenomicDist, .colorGenomicDistCol, chromCol, initialChrom, posCol, initialPos )
  }

  if( copyData )
    DATA = copy( data )
  else
    DATA = data

  DATA[ , INTERNAL_SHINY_TEXT := sprintf( "%s; %s", get( chromCol ), format( round( get( posCol ) ), big.mark = "," ) ) ]
  if( !is.null( textCol ) )
    DATA[ , INTERNAL_SHINY_TEXT := sprintf( "%s <br> %s", INTERNAL_SHINY_TEXT, get( textCol ) ) ]

  chart = utils.plotly.scatter(
    DATA,
    columns,
    xAxisTitle = xAxisTitle,
    yAxisTitle = yAxisTitle,
    colorCol = colorCol,
    textCol  = "INTERNAL_SHINY_TEXT",
    chartClass = utils.plotly.scatter.genomic.class,
    colorBarTitle = ifelse( colorCol == .colorGenomicDistCol, "bps", colorCol ),
    copyData = FALSE
  )
  chart$colorGenomicDist  = colorGenomicDist
  chart$chromCol = chromCol
  chart$posCol   = posCol
  chart$chrom    = initialChrom
  chart$pos      = initialPos

  # if using genomic distance coloring then add callback
  if( !is.null( colorGenomicDist ) )
    utils.plotly.genomic.link( chart, chart )

  return( chart )
}

###################################################################/
# utils.plotly.genomic.link ####
###################################################################/
utils.plotly.genomic.link = function(
  fromChart,
  toChart,
  bothWays = FALSE
)
{
  if( !utils.class.interface.implements( fromChart, "utils.plotly.genomic.interface" ) &&
      !utils.class.interface.implements( fromChart, "utils.plotly.genomicRange.interface" ) )
    utils.throw( "fromChart must implement either genomic or genomicRange interfaces")

  if( !utils.class.interface.implements( toChart, "utils.plotly.genomic.interface" ) &&
      !utils.class.interface.implements( toChart, "utils.plotly.genomicRange.interface" ) )
    utils.throw( "toChart must implement either genomic or genomicRange interfaces")

  # link one way
  fromChart$addCallBackGenomic( toChart )

  if( bothWays == TRUE )
    toChart$addCallBackGenomic( fromChart )
}

###################################################################/
# utils.plotly.genomicRange.interface ####
###################################################################/
utils.plotly.genomicRange.interface = utils.class.interface(
  interfacename = "utils.plotly.genomicRange.interface",
  active        = list(
    chrom        = function() return(),
    posMin       = function() return(),
    posMax       = function() return(),
    chromCol     = function() return(),
    posCol       = function() return(),
    defaultWidth = function() return()
  ),
  public = list(
    update             = function() return(),
    addCallBackGenomic = function() return()
  )
)

###################################################################/
# utils.plotly.track.genomic.class ####
###################################################################/
utils.plotly.track.genomic.class = utils.class(
  classname  = "utils.plotly.track.genomic.class",
  inherit    = utils.plotly.scatter.class,
  interfaces = list( utils.plotly.genomicRange.interface ),

  ###################################################################################/
  # private variables to record where genomic data is
  ###################################################################################/
  private = list(
    .chromCol = NULL,
    .posCol   = NULL,
    .chrom    = "chr1",
    .posMin   = 1,
    .posMax   = 1,
    .defaultWidth = 1e5
  ),

  public = list(
    ###################################################################################/
    # update
    ###################################################################################/
    update = function( genomicPos = NULL )
    {
      if( !is.null( genomicPos ) )
      {
        if( inherits( genomicPos, "utils.genomicPoint.class" ) )
        {
          self$chrom  = genomicPos$chrom
          self$posMin = genomicPos$pos - self$defaultWidth / 2
          self$posMax = genomicPos$pos + self$defaultWidth / 2
        }
        else
        if( inherits( genomicPos, "utils.genomicRange.class" ) )
        {
          self$chrom  = genomicPos$chrom
          self$posMin = genomicPos$posMin
          self$posMax = genomicPos$posMax
        }
        else
          utils.throw( "can only accept a genomicRange or genomicPoint" )
      }

      data     = self$data

      # only show relevant chromosomes
      chromCol = self$chromCol
      CHROM    = self$chrom
      data[ , INTERNAL_SHINY_SHOW := get( chromCol ) == CHROM ]

      # only show relevant positions
      posCol = self$posCol
      posMin = self$posMin
      posMax = self$posMax
      if( !is.null( posMin ) )
        data[ , INTERNAL_SHINY_SHOW := INTERNAL_SHINY_SHOW & get( posCol ) > posMin ]
      if( !is.null( posMax ) )
        data[ , INTERNAL_SHINY_SHOW := INTERNAL_SHINY_SHOW & get( posCol ) < posMax ]

      self$setRV( "data", data )
      self$setRV( "xmin", posMin )
      self$setRV( "xmax", posMax )
      super$update()
    },

    ###################################################################################/
    # addCallBackGenomic
    ###################################################################################/
    addCallBackGenomic = function( obj )
    {
      cb = function( posMin, posMax, yMin, yMax )
      {
        p = utils.genomicRange.class$new( chrom = self$chrom, posMin = posMin, posMax = posMax )
        obj$update( p )
      }

     self$callBacks$addOnRelayoutCallBack( cb )
    }
  ),

  ###################################################################################/
  # set and get where genomic data is stored
  ###################################################################################/
  active = list(
    ###################################################################################/
    # chromCol
    ###################################################################################/
    chromCol = function( col )
    {
      if( missing( col ) )
        return( private$.chromCol )

      private$.chromCol = col
    },

    ###################################################################################/
    # posCol
    ###################################################################################/
    posCol = function( col )
    {
      if( missing( col ) )
        return( private$.posCol )
      private$.posCol = col
    },

    ###################################################################################/
    # chrom
    ###################################################################################/
    chrom = function( chrom )
    {
      if( missing( chrom ) )
        return( private$.chrom )
      private$.chrom = chrom

    },

    ###################################################################################/
    # posMin
    ###################################################################################/
    posMin = function( pos )
    {
      if( missing( pos ) )
        return( private$.posMin )

      private$.posMin = pos
    },

    ###################################################################################/
    # posMax
    ###################################################################################/
    posMax = function( pos )
    {
      if( missing( pos ) )
        return( private$.posMax )

      private$.posMax = pos
    },

    ###################################################################################/
    # defaultWidth
    ###################################################################################/
    defaultWidth = function( defaultWidth )
    {
      if( missing( defaultWidth ) )
        return( private$.defaultWidth )

      private$.defaultWidth = defaultWidth
    }
  )
)

###################################################################/
# utils.plotly.track.genomic ####
###################################################################/
utils.plotly.track.genomic = function(
  data,
  chromCol   = "chrom",
  posCol     = "chromMid",
  valCol     = "dataValue",
  xAxisTitle = "position",
  yAxisTitle = "value",

  colorCol       = NULL,
  textCol        = NULL,
  initialChrom   = data[ 1, get( chromCol ) ],
  initialPosMin  = NULL,
  initialPosMax  = NULL,
  defaultWidth   = 1e4,
  copyData       = TRUE
)
{
  if( !utils.data.table.containsColumns( data, c( chromCol, posCol, valCol ) ) )
    utils.throw( sprintf( "data must contains %s (chromCol) and %s (posCol) and %s (valCol)", chromCol, posCol, valCol ) )

  if( copyData )
    DATA = copy( data )
  else
    DATA = data

  DATA[ , INTERNAL_SHINY_TEXT := sprintf( "%s; %s; %.3f", get( chromCol ), format( round( get( posCol ) ), big.mark = "," ), get( valCol ) ) ]
  if( !is.null( textCol ) )
    DATA[ , INTERNAL_SHINY_TEXT := sprintf( "%s <br> %s", INTERNAL_SHINY_TEXT, get( textCol ) ) ]

  DATA[ , INTERNAL_SHINY_SHOW := get( chromCol ) == initialChrom ]
  if( !is.null( initialPosMin ) )
    DATA[ , INTERNAL_SHINY_SHOW := INTERNAL_SHINY_SHOW & get( posCol ) > initialPosMin ]
  if( !is.null( initialPosMax ) )
    DATA[ , INTERNAL_SHINY_SHOW := INTERNAL_SHINY_SHOW & get( posCol ) < initialPosMax ]

  chart = utils.plotly.scatter(
    DATA,
    c( posCol, valCol ),
    xAxisTitle = xAxisTitle,
    yAxisTitle = yAxisTitle,
    colorCol   = colorCol,
    textCol    = "INTERNAL_SHINY_TEXT",
    chartClass = utils.plotly.track.genomic.class,
    copyData   = FALSE,
    mode       = "lines"
  )
  chart$chromCol = chromCol
  chart$posCol   = posCol
  chart$chrom    = initialChrom
  chart$posMin   = initialPosMin
  chart$posMax   = initialPosMax
  chart$defaultWidth = defaultWidth

  cb = function( xmin, xmax, ymin, ymax )
  {
    chart$posMin = xmin
    chart$posMax = xmax
    if( is.null( xmin ) | is.null( xmax ) )
       chart$update()
  }
  chart$callBacks$addOnRelayoutCallBack( cb )

  return( chart )
}

