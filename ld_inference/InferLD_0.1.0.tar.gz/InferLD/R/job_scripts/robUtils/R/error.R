###################################################################
# Name:       utils.throw
# Descrption: throws error with a message and prints callstack
#             currently no catching mechanism so simply stop
# Args:       character
# Return:
###################################################################
utils.throw = function( message = "" )
{
  print( sprintf( "ERROR: %s", message ), quote = FALSE )
  traceback()
  stop()
}
