if( !exists( "cacheEnv" ) )
  cacheEnv = new.env()

###################################################################/
# wrapper to get gaussHermite quadrature points and weights
###################################################################/
.gaussHermiteRules = function( nPoints )
{
  tag = sprintf( "gaussHermiteRules_%d", nPoints )
  if( !exists( tag, envir = cacheEnv ) )
    assign( tag, hermite.h.quadrature.rules( nPoints )[[ nPoints ]], envir = cacheEnv )
  return( get( tag, envir = cacheEnv ))
}

###################################################################/
# wrapper to get gaussLaguerre quadrature points and weights
###################################################################/
.gaussLaguerreRules = function( nPoints )
{
  tag = sprintf( "gaussLaguerreRules_%d", nPoints )
  if( !exists( tag, envir = cacheEnv ) )
    assign( tag, laguerre.quadrature.rules( nPoints )[[ nPoints ]], envir = cacheEnv )
  return( get( tag, envir = cacheEnv ))
}

###################################################################/
# Name:       utils.integrate.logunimodal.vectorized
# Descrption: vectorized version of integrating a large number of
#             integrals which are vectorized
#             integral of form int_0^infty exp( f(x ) ) dx
# Args:       f   - funciton in exponential of integrand
#             max - esimtae of the maximum of the integramd
# Return:     vector of log of integrals
###################################################################/
utils.integrate.logunimodal.vectorized = function( f, max, xmin = 1e-6 , left  = pmax( pmin( max/2, max - 1 ), xmin ), right = pmax( max * 2 , max + 1 ), nGaussPoints = 21, maxExpand = 5  )
{
  # how many integrals are we doing
  nInt = length( max )

  # check bracketing
  fmax   = f( max )
  if( length( fmax ) != nInt )
    utils.throw( "return length of the function and max must be the same")
  fleft  = f( left )
  fright = f( right )

  if( sum( ( fmax < fleft ) * ( left > xmin ) > 0 ) )
    utils.throw( "the left hand bracket is larger than value at the estimate of the maximum" )

  miss = fmax < fright
  if( sum( miss  ) > 0 )
  {
    expandDx = 1
    while( expandDx < maxExpand )
    {
      expandDx      = expandDx + 1 
      right[ miss ] = right[ miss ] * 2
      fright        = f( right )
      miss          = fmax < fright
      if( sum( miss ) == 0 )
        break()
    }
    if( sum( miss  ) > 0 )
      utils.throw( "the right hand bracket is larger than value at the estimate of the maximum" )
  }

  # find max exactly of (log) integrand
  optim = utils.optimise.vectorized( f, left, max, right, maximum = T, tol = 1e-8 )

  # do the interior integrals using Gauss-Hermite quadrature and boundary using Guass-Laguerre
  # get the second derivs and deriv to rescale the width
  eps    = 1e-4 * ( 1 + optim$maximum );
  fr     = f( optim$maximum + eps )
  deriv  = abs( ( fr - optim$objective ) / eps )
  deriv2 = ( fr + f( optim$maximum - eps ) - 2 * optim$objective ) / eps / eps

  # evaluate using either Gauss-Hermite or Gauss-Laugerre quadrature depending on whether on boundary
  boundIdx = which( optim$maximum < 10 * xmin | deriv2 >= 0 )
  midIdx   = setdiff( 1:nInt, boundIdx )

  # get the quadrature points
  ruleGH = .gaussHermiteRules( nGaussPoints )
  ruleGL = .gaussLaguerreRules( nGaussPoints )

  # take weighted sum over quarature points
  int = rep( 0, nInt)
  xs  = rep( 0, nInt )

  for( pdx in 1:nGaussPoints )
  {
    # calculate the x values to evaluate for the 2 different cases
    xs[ midIdx ]   = optim$maximum[ midIdx ] + sqrt( - 2 / deriv2[ midIdx ] ) * ruleGH[ pdx, 1 ]
    xs[ boundIdx ] = ruleGL[ pdx, 1 ] / deriv[ boundIdx ]

    # evaluate the function value once for both types of integrals
    fs = f( pmax( xmin, xs ) )

    # now add to integrals with correct transformation and weight
    int[ midIdx ]   = int[ midIdx ] + ruleGH[ pdx, 2 ] * exp( fs[ midIdx ] - optim$objective[ midIdx ] + ruleGH[ pdx, 1 ]^2 )
    int[ boundIdx ] = int[ boundIdx ] + ruleGL[ pdx, 2 ] * exp( fs[ boundIdx ] - optim$objective[ boundIdx ] + ruleGL[ pdx, 1 ] )
  }

  # put back the maximum and the rescalinbg
  int             = optim$objective + log( int )
  int[ midIdx ]   = int[ midIdx ] + 0.5 * log( 2 ) - 0.5 * log( - deriv2[ midIdx ] )
  int[ boundIdx ] = int[ boundIdx ] - log( deriv[ boundIdx ] )

  return( int )
}
