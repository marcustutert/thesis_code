###################################################################################/
# utils.plot.multi
###################################################################################/
utils.plot.multi = function(
  ...,              # ggplots or a lists of ggplots
  ncol    = 1,      # number of columns
  nrow    = NULL,   # number of rows, if null then filled up
  widths  = NULL,   # vector of length cols and weights of the widths of the cells
  heights = NULL    # vector of length rows and weights of the heights of the cells
  )
{
  # flatten the list of plots in to a single list (harder than expected since ggplot is a list!)
  plots = list( ... )
  plots = lapply( plots, function( x ) if( is.ggplot( x ) || is.null( x ) ) list( x ) else x )
  plots = unlist( plots, recursive = FALSE)

  # calculate the dimensions of grid if not given
  if( is.null( ncol ) )
    utils.throw( "must specify the number of columns" )
  nPlots = length( plots )
  if( is.null( nrow ) )
    nrow = ceiling( nPlots / ncol )

  # calculate the widths and heights
  if( is.null( widths ) )
    widths = rep( 1, ncol )
  else
  if( length( widths ) != ncol )
    utils.throw( "if specify widths then it must be a vector of length ncol" )
  if( is.null( heights ) )
    heights = rep( 1, nrow )
  else
   if( length( heights ) != nrow )
    utils.throw( "if specify heights then it must be a vector of length nrow" )

  # now set up the grid layout
  layout = grid.layout( nrow, ncol, widths = unit( widths, "null" ), heights = unit( heights, "null" ) )
  grid.newpage()
  pushViewport( viewport( layout = layout ) )

  # finally do the plots
  for( i in 1:nPlots )
    if( !is.null( plots[[ i ]]) )
      print( plots[[ i ]], vp = viewport( layout.pos.row = ceiling( i / ncol ), layout.pos.col = ( ( i - 1 ) %% ncol ) + 1 ) )
}

###################################################################################/
# utils.plot.correlationMatrix
###################################################################################/
utils.plot.correlationMatrix = function(
  matrix,
  autoScale = T,
  show      = T
)
{
  # convert to a data.table with a row per cell
  corr = as.data.table( matrix )
  corr[ , idx :=  names( corr )]
  corr$idx = factor( corr$idx, levels = corr[[ "idx"]] )
  corr = melt.data.table( corr, "idx", corr[ , idx], variable.name = "idx2")

  # if not autoScale then force z-axis to -1 to 1
  if( autoScale )
    p = plot_ly(corr, x = ~idx, y = ~idx2, z = ~value, type = "heatmap", colorscale = "Greys" )
  else
    p = plot_ly(corr, x = ~idx, y = ~idx2, z = ~value, type = "heatmap", zmin = -1, zmax = 1, zauto = FALSE, colorscale = "Greys")

  p = layout( p, margin = list( l = 100, b = 100 ), xaxis = list( title = "" ), yaxis = list( title = "" ) )

  if( show )
    show( p )

  return( p )

}
