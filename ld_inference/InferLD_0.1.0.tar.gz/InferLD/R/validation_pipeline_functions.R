#' @export
LD_from_GSHMM = function(ref_allele_matrix,
                         fst,
                         alpha,
                         nSamples,
                         weights_resolution,
                         likelihood_toggle,
                         gwas_variance,
                         LD_Infer,
                         recombination,
                         case_control_constant,
                         debug,
                         BurnIn){
  
  #First get the constants that we need
  ref_panel_haplotypes = as.matrix(ref_allele_matrix)
  nsnps                = ncol(ref_allele_matrix)
  nhaps                = nrow(ref_allele_matrix)

  #Do the Gibbs Sampling process, store the results to an array
  gibbs_results           = gibbs_sampler(nSamples              = nSamples,
                                          weights_resolution    = weights_resolution,
                                          ref_allele_matrix     = ref_allele_matrix,
                                          fst                   = fst,
                                          alpha                 = alpha,
                                          likelihood            = likelihood_toggle,
                                          gwas_variance         = gwas_variance,
                                          recombination         = recombination,
                                          case_control_constant = case_control_constant,
                                          debug                 = debug)
  #Specific results we can store
  HW_Array       = gibbs_results$Gibbs_Array
  likelihood     = gibbs_results$log_likelihood
  allele_freq    = gibbs_results$inferred_af_given_weights

  #Store constants
  nsnps = ncol(ref_panel_haplotypes)
  nhaps = nrow(ref_panel_haplotypes)

  #Perform the LD inference
  if (LD_Infer == TRUE) {
    #burnIn_samples = floor(.9*(nSamples-1))
    burnIn_samples   = 1
    pseudo_LD_array  = array(data = rep(NA,nsnps*nsnps*(length(burnIn_samples:dim(HW_Array)[3]))),
                             dim  = c(nsnps,nsnps,length(burnIn_samples:dim(HW_Array)[3])))

    #Skip burnIn of 90% (Hard coded in for now )
    ld_sample = 1
    for (i in burnIn_samples:(dim(HW_Array)[3])) {
      flush.console()
      cat(sprintf("On Iteration %s for LD Inference", ld_sample))
      Qx_Array             = markovian_flow(HW_Matrix     = HW_Array[,,i],
                                            start         = 1,
                                            end           = nsnps,
                                            recombination = recombination)

      pseudo_LD_array[,,ld_sample] = LD_flow_expectation(HW_Matrix         = HW_Array[,,i],
                                                         ref_allele_matrix = ref_panel_haplotypes,
                                                         Qx_array          = Qx_Array,
                                                         recombination     = recombination)
      ld_sample = ld_sample + 1
    }

  return(list("Gibbs_Array"                 =  HW_Array,
                "log_likelihood"            =  likelihood,
                "inferred_af_given_weights" =  allele_freq,
                "chosen_states"             =  chosen_states,
                "LD_Array"                  =  pseudo_LD_array))
  }
  return(list("Gibbs_Array"               = HW_Array,
              "log_likelihood"            = likelihood,
              "inferred_af_given_weights" = allele_freq))
}
