#Playground for testing Gibbs sampling of my HMM to predict GWAS haplotypes
library(stats)
library(plotly)
library(data.table)
###################################################################/
# Reading in the Data from 1000G
###################################################################/

haps = fread("~/Desktop/Oxford_Dphil/EstimateLD/tests/Data/Eur_Chr22_Filtered_First_40K_Variants.haps", header = TRUE)
haps<-haps[,-1:-5] #Take away all the naming conventions

#Create haplotype column names
hap_names <- sprintf("hap%s",seq(1:ncol(haps)))
colnames(haps) =  hap_names

#Transpose matrix to get it in same form as my other data
haps = t(haps)

###################################################################/
# Pick how big we want reference panel to be and the size of the region
###################################################################/
ref_panel_size = 100
haps           = haps[sample(nrow(haps), ref_panel_size), ]
nsnps          = 10
haps = haps[,1:nsnps]

###################################################################/
# Cleaning and Filtering the Data
###################################################################/
#Look at the initial pi_ref's make sure that they look ok...
pi_ref = colSums(haps)/nrow(haps)

#Restrict to only variants that are segregating in both populations and have an MAF > 0.1%.
seg_snps = which(pi_ref<0.95 & pi_ref>0.05)
haps = haps[,seg_snps]
pi_ref = colSums(haps)/nrow(haps)

###################################################################/
# Simulating the GWAS SE's from Drifted Pi_Pops
###################################################################/

#Get number of snps and haps from our ref_allele panel (haps)
nsnps = ncol(haps)
nhaps = nrow(haps)

#Now let's generate a list of drifted pi_pop's with NB model
Fst    = 0.01
# c      = 1/Fst-1
# alpha  = c*pi_ref
# beta   = c*(1-pi_ref)
# pi_pop = rbeta(nsnps, alpha, beta) Nichols Balding (infinite recomb.)

#Sample from a Gamma Distribution
sample_weights           = rgamma(n = nhaps, shape = 1/(nhaps*Fst), scale = 1)
normalize_sample_weights = sample_weights/(sum(sample_weights))
pi_pop                   = colSums(haps * normalize_sample_weights)

#Add some multiplicative Gamma noise on top of this
alpha = 1e2 #Larger alpha = smaller noise

#Generate the sigma^2 observed
observed_sigma_b = 1/(pi_pop*(1-pi_pop))*rgamma(nsnps,shape = alpha, scale = 1/alpha)

###################################################################/
# Do we Recover Nichols Balding Prior
###################################################################/

recomb_rate = 0.99 #Set recombination very high to have independence between SNP's
nSamples    = 1e3
weights_resolution = 10

#Generate the Gamma Quantiled Weight Space
Gamma_Quantiled_Weights = Gamma_Weight_States(weights_resolution = weights_resolution, Fst = Fst, ref_allele_matrix = haps)

#Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to nhaps)
weight_matrix = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps )
#Create matrix of allele-frequencies to vectorize this all, use the code from Scratch for this purpose
Gibbs_Allele_Freq = matrix(data = NA, nrow = nsnps, ncol = nSamples)
weights_matrix_sum       = colSums(weight_matrix)
weight_matrix_normalized = sweep(weight_matrix, 2, weights_matrix_sum, FUN = '/')

Gibbs_Allele_Freq[,1]    = colSums(haps*weight_matrix_normalized)

#Run the Gibbs Sampling
for (j in 2:nSamples) {
  cat( sprintf("\r%d", j))
  for (idx in 1:nhaps){
    weight_initializion = weight_update(ref_allele_matrix = haps, fst = Fst, weight_matrix = weight_matrix, Gamma_Weights_States = Gamma_Quantiled_Weights, row_update = idx)

    #Use the function for prob given the implied sigma_b
    prob_normalized = prob_sigma_given_frequency(allele_frequency_matrix = weight_initializion, observed_sigma_b = observed_sigma_b, likelihood = FALSE, noise = alpha)

    #Get the forward pass through this matrix
    forward_pass_matrix = forward_pass(allele_frequency_matrix = prob_normalized, diag_transition = 1-recomb_rate)

    #Sample backwards through this forward matrix to get a single path through the posteriors
    path =  sample_HMM_path(forward_pass_matrix = forward_pass_matrix, diag_transition = 1-recomb_rate)
    weight_matrix[idx,] = Gamma_Quantiled_Weights[path]
  }
  weights_matrix_sum       = colSums(weight_matrix)
  weight_matrix_normalized = sweep(weight_matrix, 2, weights_matrix_sum, FUN = '/')
  Gibbs_Allele_Freq[,j]    = colSums(haps*weight_matrix_normalized)
}

###################################################################/
# Analyzing the Pi_Refs and Pi_Pops
###################################################################/

#Get the pi_pops for each sample from the Gibbs_Allele_Freq Matrix
pi_pop_per_sample = Gibbs_Allele_Freq
#Let's look at the second pi_ref and the corresponding pi_pops
variant = 2 #Can change this number around
pi_ref[variant] #Look at the MAF here
pi_pop = pi_pop_per_sample[variant,] #These are all the sample pi_pops under the Fst model

#Want these densities to compare with Nichols and Balding Model
density1 = density(pi_pop) #Empirical Density

#Nichols Balding Model parametrization
c = 1/Fst-1
alpha = c*pi_ref[variant]
beta  = c*(1-pi_ref[variant])
density2 = density(rbeta(n = 5e5, shape1 = alpha, shape2 = beta)) #N-B Density

#Plot the Densities of Empirical vs Observed
p <- plot_ly(x = ~density1$x, y = ~density1$y, type = 'scatter', mode = 'lines', name = 'Empirical Density', fill = 'tozeroy') %>%
  add_trace(x = ~density2$x, y = ~density2$y, name = 'Theoretical Density', fill = 'tozeroy') %>%
  layout(xaxis = list(title = 'Pi_Pop'),
         yaxis = list(title = 'Density'))

show(p)
