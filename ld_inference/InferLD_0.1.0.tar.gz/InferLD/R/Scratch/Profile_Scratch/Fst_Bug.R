# profvis({LD_from_GSHMM(se_observed     = ss[1:100,3]^2/0.001,
#               ref_panel_haplotypes  = unique(as.matrix(ref[,1:100])),
#               Fst                   = 0.9,
#               alpha                 = 1e3,
#               recomb_rate           = 0.01,
#               initial_temperature   = 1,
#               cooling_alpha         = 1,
#               weights_resolution    = 100,
#               nSamples              = 200,
#               LD_Infer              = FALSE,
#               beta_ll               = FALSE,
#               beta_observed         = (ss[,2]/ss[,3])^2,
#               noise_factor          = 1,
#               nearest_neighbour     = FALSE)})
# p = profvis({LD_flow_expectation(HW_Matrix           = HV[,1:30],
#                                ref_allele_matrix = unique(ref)[,1:30],
#                                Qx_array          = Qx_Array[,,1:30])})
Qx_Array = markovian_flow(HW_Matrix = HV_Avg,start = 1,end =370)
ld = LD_flow_expectation(HW_Matrix = HV_avg,ref_allele_matrix = unique(ref),Qx_array = Qx_Array)
