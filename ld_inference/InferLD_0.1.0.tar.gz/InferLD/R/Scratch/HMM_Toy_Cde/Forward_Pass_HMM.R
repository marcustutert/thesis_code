#Coding up an HMM Forward Algorithim. We wish to do this both a quick way (using the constraints we can put on the transition matrix
#And also a slow way to double check our code, ie the normal way that takes O(TN^2) operations, vs the faster O(NK) ways.

#To do this we'll start with an easy example with observation sequence length of 4, and and HMM model (lambda = A,B,pi)
#That has 3 possible (hidden) states

#Therefore we will have a transition matrix that has NxN dimensions
#But lets exploit the property that we'll have in the actual transition matrixs when it comes to the haplotype weights.
#Ie we will say that the only times when we don't have the same transition is when i = j, if i != j then we will say that
#The state you come from doesn't really matter at all

A = rbind(c(0.9,0.05,0.05),c(0.05,0.9,0.05),c(0.05,0.05,0.9))

#Check that A is row-stochastic (that is all the probabilities sum to 1 across the rows)
rowSums(A) #Yes we are good.

#Now let's define what our B is, which will be our probability matrix.
B = rbind(c(0.3,0.2,0.5),c(0.2,0.6,0.2),c(0.1,0.3,0.6))
#Check that B is row-stochastic (that is all the probabilities sum to 1 across the rows)
rowSums(B) #Yes we are good

#Now we just need to figure out which distribution we are in first, by setting a value of pi, this need to be a vector (length of N)
pi_initial = c(1/3,1/3,1/3)
#Again this needs to sum to one, but since its just uniform distribution it will, and we are fine.

#Lastly, let's define our observation sequence, we'll just keep things numeric, so things can be in either S = {1,2,3}
#Let's say we have
Obs = c(2,1,3,1) #Second observation -> First observation -> Third Observation

#Matrix way of doing things (look at HMM page for Matthew Stephens)
alpha      = matrix(nrow = ncol(B),ncol=length(Obs))

# Initialize alpha[1,]
for(k in 1:ncol(B)){
  alpha[k,1] = pi_initial[k] * B[k,Obs[1]]
}

# Forward algorithm
for(t in 1:(length(Obs)-1)){
  m = A %*%  alpha[,t]
  for(k in 1:nrow(B)){
    alpha[k,t+1] = m[k]*B[k,Obs[t+1]]
  }
}

####Fast Forward Algorithim
alpha_fast = matrix(nrow = ncol(B),ncol=length(Obs))

# Initialize alpha[1,]
for(k in 1:ncol(B)){
  alpha_fast[k,1] = pi_initial[k] * B[k,Obs[1]]
}

#Go through algorithim
#C is 0.05 which is the majority of our transition matrix
#C-Aij is 0.9-0.05 (so non-constants minus the constants)
#Now this is done in O(t) time
for(t in 1:(length(Obs)-1)){
  #Sum the non mixed states
  alpha_fast[,t+1] = sum(alpha_fast[,t])*0.05
  #Sum the mixed states as well as the averaging factor
  alpha_fast[,t+1] = (alpha_fast[,t]*0.85) + alpha_fast[,t+1]
  #Now multiply by the observed probability at the length in the sequence
  alpha_fast[,t+1] = alpha_fast[,t+1] * B[,Obs[t+1]]
}

#Go through and sample a SINGLE path through this matrix
#We want to use a empty vector at the start to store the sequence of these path through (what weights do we visit?)
path = rep(NA,length(Obs))
#Use the sample function in R to figure out where we are starting from in this forward pass matrix at the last column (T-1)?
chosen_state_probability = sample( x = alpha_fast[,length(Obs)], size = 1, prob = alpha_fast[,length(Obs)]/sum(sum(alpha_fast[,length(Obs)])))
#Now we want to see which state this probability would have come from; so that we can store our path through....
path[length(Obs)] = which(alpha_fast[,length(Obs)] == chosen_state_probability)

# #Now that we've picked our starting point we need to actually care about the transition probabilities etc to move through this matrix
# #To do this lets consider the case where i->j is some very small value (always the same) but i->i is a very high value (kinda like recombination)
# #Basically we end up with our a_ij looking like a vector where everything is that small value, except at the place where we have the state we just picked
# a_ij = rep(0.05,nrow(alpha_fast))
# #Now replace the state where we've just come from (ie if its 2, then the second element in the vector becomes the high value from our transition matrix)
# a_ij[path] = 0.9
#
# #Now multiply this through the forward_pass at T-2 (second last column)
# probabilities = a_ij * alpha_fast[,length(Obs)-1]
# #Normalize these probabilities to sum to 1
# probabilities = probabilities/sum(probabilities)
#
# #Now we just sample from here
# chosen_state_probability = sample( x = alpha_fast[,length(Obs)-1], size = 1, prob = probabilities)
# path[2] = which(alpha_fast[,length(Obs)-1] == chosen_state_probability)

#Now let's do this actually with a proper FOR loop here:
for (i in rev(seq(length(Obs):1))[-length(Obs)]) {
  a_ij = rep(0.05,nrow(alpha_fast))
  a_ij[path[i]] = 0.9
  probabilities = a_ij * alpha_fast[,i-1]
  probabilities = probabilities/sum(probabilities)
  chosen_state_probability = sample( x = alpha_fast[,i-1], size = 1, prob = probabilities)
  path[i-1] = which(alpha_fast[,i-1] == chosen_state_probability)
}




