#Scratch Code to initialize the weights in the haplotype-variant matrix
#Set a seed so that Rob can do testing on his own
set.seed(245)

#Set number of haplotypes and variants to a small number so we can do testing and debugging
nhaps = 100  #10 haplotypes in reference panel
nsnps = 1000 #100 variants in reference panel

#What is the Fst between the reference panel and the simulated GWAS dataset
fst   = 0.01

#First we want to generate draws from the gamma distribution, we do this with rgamma:
weights = rgamma(n = 10, shape = 10, scale = 1) #n control the number of draws

#But we want to discretize the weight space into quantiles so that we can perform weight updates
#These quantiles will divide the range of the gamma generated random deviates
#Ie if we wanted the 20% quantile, we would be looking for the point in our dataset that have 20% of the draws below it

#Quantile(x = numeric vector of our draws, probs = vector of probabilities)
quantile( x = weights, probs = c( 0.5 )) #This number tells us 50% of the data is below 8.14, which makes sense

#Let's say we have 10 quantiles for now, at the Decile range
quantile( x = weights, probs = seq( 0, 1, 0.1 ) )

#Now we want to set out gamma distribution to be marginally dirichlet distributed with the correct parameters.We set
#Shape = 1/(N*Fst) and Scale = 1

#Set the weights for a single haplotype
weights = rgamma(n = 10, shape = 1 / ( nhaps * Fst ) , scale = 1 )

#Set the weights equal to one and enfornce marginal dirichlet distribution
normalized_weights = weights/sum(weights) #Doing this would be the 'slow' way of doing things...we don't want to store the normalized weights

#Let's now generate our weight matrix, so generate 10x100 draws
#Generate weights that come from a 'Decile' Quantiled Gamma draw with (1/(nhaps*Fst),1) parametrization
#Change number of Quantiles can come later
Gamma_Quantiled_Weights = qgamma(p = seq(0,1,0.1), shape = 1 / ( nhaps * Fst ), scale = 1 )

#Remove first and last quantile (0 and infinite respectively)
Gamma_Quantiled_Weights = Gamma_Quantiled_Weights[is.finite(Gamma_Quantiled_Weights) & Gamma_Quantiled_Weights>0]

#Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to N)
weight_matrix = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps )

#Generate a Reference Allele Panel with {1,0} to denote variant or no variant
#First let's generate a list of random pi_ref allele frequencies that we want this to look like
ref_allele_matrix = matrix( rbinom( nhaps * nsnps , 1 , prob = runif( nsnps, min = 0, max = 0.5 ) ), ncol = nsnps, nrow = nhaps )
pi_ref            = colSums( ref_allele_matrix ) / nhaps
print(pi_ref[1])

#Let's say we are updating the last row of haplotype weights for every SNP in our weight_matrix
#We want to calculate the allele frequencies at each SNP if the quantile where that haplotype was originally placed, jumped to any other quantiles
#This means we will be calculating a matrix of allele frequencies of nsnps * number of quantiles
#We want to do this without having to normalize each step etc to save time!

#This is for the very first SNP, if we jump from the first quantile to the second quantile
sum_unnormalized_weights            = sum(weight_matrix[,1][-length(weight_matrix[,1])]) + Gamma_Quantiled_Weights[1]
sum_unnormalized_weights_ref_allele = sum(weight_matrix[,1][-length(weight_matrix[,1])] * ref_allele_matrix[,1][-length(ref_allele_matrix[,1])]) + ref_allele_matrix[nhaps,1]*Gamma_Quantiled_Weights[1]

#Do divison to get the allele frequency (quick way)
print(sum_unnormalized_weights_ref_allele/sum_unnormalized_weights)

#If we were to normalize etc and do it the slow way, what would we get as our allele frequency?
weight_matrix[nhaps,1]        = Gamma_Quantiled_Weights[1]
normalized_weights            = weight_matrix[,1] / sum(weight_matrix[,1])
print(sum(normalized_weights * ref_allele_matrix[,1]))
#This method should give us the same result as the method above

#Now let's go and do this for all possible quantiles that the first weight can 'jump' to, this means we will get a vector of allele frequencies for the first SNP
#Initialize a new weight matrix for completeness
weight_matrix                       = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps )
sum_unnormalized_weights            = sum(weight_matrix[,1][-length(weight_matrix[,1])]) + Gamma_Quantiled_Weights
sum_unnormalized_weights_ref_allele = sum(weight_matrix[,2][-length(weight_matrix[,2])] * ref_allele_matrix[,2][-length(ref_allele_matrix[,2])]) + ref_allele_matrix[nhaps,2]*Gamma_Quantiled_Weights
allele_frequency_fast_first_variant = sum_unnormalized_weights_ref_allele/sum_unnormalized_weights

#To test that this works with the slow way of doing things, we'll pick let's say the 3rd quantile jump, and see if that makes sense
weight_matrix[nhaps,1]        = Gamma_Quantiled_Weights[3]
normalized_weights            = weight_matrix[,1] / sum(weight_matrix[,1])
print(sum(normalized_weights * ref_allele_matrix[,1]))
print(allele_frequency_fast_first_variant[3]) #These two values should be equal which they are

#Now we want to go to the last step, which is do this across a matrix of variants, that is to say, we want to calculate a matrix of allele frequencies of nsnps * number of quantiles
#Again let's re-initialize our weight matrix for this
weight_matrix                       = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps )
sum_unnormalized_weights            = outer(colSums(weight_matrix[-nhaps,]),Gamma_Quantiled_Weights, FUN='+')
x1                                  = t(replicate(nhaps-1,colSums(weight_matrix[-nhaps,]*ref_allele_matrix[-nhaps,])))
x2                                  = outer(Gamma_Quantiled_Weights, ref_allele_matrix[nhaps,], FUN ='*')
sum_unnormalized_weights_ref_allele = x1 + x2
allele_frequencies                  = t(sum_unnormalized_weights_ref_allele)/sum_unnormalized_weights

#Doing this the slow way would be very laborious...we would have to normalize every step as we do below
#Lets start with easy thing, and only worry about first SNP, then can loop over other rows accordingly.
weight_matrix_gamma_added = rbind(replicate(length(Gamma_Quantiled_Weights),weight_matrix[(1:nhaps-1),1]),Gamma_Quantiled_Weights)
#Normalize the columns
weight_matrix_normalized = matrix(data = NA, ncol = length(Gamma_Quantiled_Weights), nrow = nhaps)
for (i in 1:ncol(weight_matrix_normalized)) {
  weight_matrix_normalized[,i] = weight_matrix_gamma_added[,i]/sum(weight_matrix_gamma_added[,i])
}
colSums(weight_matrix_normalized * ref_allele_matrix[,1])

#Now we want to do this over every possible SNP
allele_frequencies_slow = matrix(data = NA, nrow = length(Gamma_Quantiled_Weights), ncol = nsnps)
for (i in 1:ncol(allele_frequencies_slow)) {
  weight_matrix_gamma_added = rbind(replicate(length(Gamma_Quantiled_Weights),weight_matrix[(1:nhaps-1),i]),Gamma_Quantiled_Weights)
  #Normalize the columns
  weight_matrix_normalized = matrix(data = NA, ncol = length(Gamma_Quantiled_Weights), nrow = nhaps)
  for (j in 1:ncol(weight_matrix_normalized)) {
    weight_matrix_normalized[,j] = weight_matrix_gamma_added[,j]/sum(weight_matrix_gamma_added[,j])
  }
  allele_frequencies_slow[,i] = colSums(weight_matrix_normalized * ref_allele_matrix[,i])
}

#It has the same allele frequency minus a machine error
allele_frequencies[3,]-allele_frequencies_slow[,3]

profvis({
EstimateLD::allele_frequency_check(ref_allele_matrix = ref_allele_matrix,fst = 0.01,weights_resolution = 10)
})

profvis({
  EstimateLD::initialize_weights(ref_allele_matrix = ref_allele_matrix,fst = 0.01,weights_resolution = 10)
})

##################################################.
############Extending to Any Row###################
###################################################.

#Set number of haplotypes and variants to a small number so we can do testing and debugging
nhaps = 5  #10 haplotypes in reference panel
nsnps = 4 #100 variants in reference panel

#What is the Fst between the reference panel and the simulated GWAS dataset
fst   = 0.01

#Let's now generate our weight matrix, so generate 10x100 draws
#Generate weights that come from a 'Decile' Quantiled Gamma draw with (1/(nhaps*Fst),1) parametrization
#Change number of Quantiles can come later
Gamma_Quantiled_Weights = qgamma(p = seq(0,1,0.1), shape = 1 / ( nhaps * Fst ), scale = 1 )

#Remove first and last quantile (0 and infinite respectively)
Gamma_Quantiled_Weights = Gamma_Quantiled_Weights[is.finite(Gamma_Quantiled_Weights) & Gamma_Quantiled_Weights>0]

#Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to N)
weight_matrix = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps )

#Generate a Reference Allele Panel with {1,0} to denote variant or no variant
#First let's generate a list of random pi_ref allele frequencies that we want this to look like
ref_allele_matrix = matrix( rbinom( nhaps * nsnps , 1 , prob = runif( nsnps, min = 0, max = 0.5 ) ), ncol = nsnps, nrow = nhaps )


 #Now we want to go to the last step, which is do this across a matrix of variants, that is to say, we want to calculate a matrix of allele frequencies of nsnps * number of quantiles
 #Again let's re-initialize our weight matrix for this
 weight_matrix                       = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps )
 sum_unnormalized_weights            = outer(colSums(weight_matrix[-2,]),Gamma_Quantiled_Weights, FUN='+')
 x1                                  = t(replicate(length(Gamma_Quantiled_Weights),colSums(weight_matrix[-2,]*ref_allele_matrix[-2,])))
 x2                                  = outer(Gamma_Quantiled_Weights, ref_allele_matrix[2,], FUN ='*')
 sum_unnormalized_weights_ref_allele = x1 + x2
 allele_frequencies                  = t(sum_unnormalized_weights_ref_allele)/sum_unnormalized_weights


#Now we want to do this over every possible SNP
allele_frequencies_slow = matrix(data = NA, nrow = length(Gamma_Quantiled_Weights), ncol = nsnps)
for (i in 1:ncol(allele_frequencies_slow)) {
  #Remove the correct row
  weight_matrix_remove_row = weight_matrix[-2,]
  #Replicate over that SNP column
  weight_matrix_replicated = replicate(length(Gamma_Quantiled_Weights),weight_matrix_remove_row[,i])
  #Add in the new column of quantiles AT THE RIGHT ROW that we have missed
  weight_matrix_modified   = rbind(weight_matrix_replicated[1:(2-1),],Gamma_Quantiled_Weights,weight_matrix_replicated[-(1:(2-1)),])
  #Normalize the columns
  weight_matrix_normalized = matrix(data = NA, ncol = length(Gamma_Quantiled_Weights), nrow = nhaps)
  for (j in 1:ncol(weight_matrix_normalized)) {
    weight_matrix_normalized[,j] = weight_matrix_modified[,j]/sum(weight_matrix_modified[,j])
  }
  allele_frequencies_slow[,i] = colSums(weight_matrix_normalized * ref_allele_matrix[,i])
}


