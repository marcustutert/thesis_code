#Playground for testing Gibbs sampling of my HMM to predict GWAS haplotypes
library(stats)
library(plotly)
library(data.table)
rm(list = setdiff(ls(), lsf.str()))

source("./R/HMM_Functions.R")
source("./R/Weights_LD_Inference.R")
###################################################################/
# Reading in the Data from 1000G
###################################################################/

haps = fread("~/Documents/EstimateLD/tests/Data/Eur_Chr22_Filtered_First_40K_Variants.haps", header = TRUE)
haps<-haps[,-1:-5] #Take away all the naming conventions

#Create haplotype column names
hap_names <- sprintf("hap%s",seq(1:ncol(haps)))
colnames(haps) =  hap_names

#Transpose matrix to get it in same form as my other data
haps = t(haps)

###################################################################/
# Pick how big we want reference panel to be and the size of the region
###################################################################/
ref_panel_size = 100
haps           = haps[sample(nrow(haps), ref_panel_size), ]
nsnps          = 100
haps = haps[,1:nsnps]

###################################################################/
# Cleaning and Filtering the Datao
###################################################################/
#Look at the initial pi_ref's make sure that they look ok...
pi_ref = colSums(haps)/nrow(haps)

#Restrict to only variants that are segregating in both populations and have an MAF > 0.1%.
seg_snps = which(pi_ref<0.95 & pi_ref>0.05)
haps = haps[,seg_snps]
pi_ref = colSums(haps)/nrow(haps)

###################################################################/
# Simulating the GWAS SE's from Drifted Pi_Pops
###################################################################/

#Get number of snps and haps from our ref_allele panel (haps)
nsnps = ncol(haps)
nhaps = nrow(haps)

#Now let's generate a list of drifted pi_pop's with NB model
Fst    = 0.001
# c      = 1/Fst-1
# alpha  = c*pi_ref
# beta   = c*(1-pi_ref)
# pi_pop = rbeta(nsnps, alpha, beta) Nichols Balding (infinite recomb.)

#Sample from a Gamma Distribution
sample_weights           = rgamma(n = nhaps, shape = 1/(nhaps*Fst), scale = 1)
normalize_sample_weights = sample_weights/(sum(sample_weights))
pi_pop                   = colSums(haps * normalize_sample_weights)

#Add some multiplicative Gamma noise on top of this
alpha = 1e2 #Larger alpha = smaller noise

#Generate the sigma^2 observed
observed_sigma_b = 1/(pi_pop*(1-pi_pop))*rgamma(nsnps,shape = alpha, scale = 1/alpha)

###################################################################/
#  Do We Converge on the Correct Allele Frequencies?
###################################################################/
#Use the new Gibbs sampling function
Gibbs_Allele_Freq = Gibbs_Sampling_HW_Array(recomb_rate = 0.01, nSamples = 1000, weights_resolution =  10, ref_allele_matrix = haps, Fst = Fst, observed_sigma_b = observed_sigma_b, alpha = 10)
####### LUKE NOTES
#Array that has the weight matrices.
#each sample is a guess. collection of guesses
#if i take one guess, it should be the same format.
#weights are integers, have to normalize the weights, ensure all colsums to 1 (normalize to sum to 1)
# note : 1 more change to allow me to play with the sankey flow diagram. Need to specify the number of haplotypes.
# convert weights to probability of haplotype identity
# the matrix is the first in the element of a list the one I want is the first one.
######

pi_imp1 = 0.5 + 0.5*sqrt( 1 - pmin( 4 / observed_sigma_b,1 ))
pi_imp2 = 0.5 - 0.5*sqrt( 1 - pmin(4 / observed_sigma_b,1 ))
pi_imp = ifelse( pi_ref > 0.5, pi_imp1, pi_imp2)

show(plot_ly( y = colMeans(abs(Gibbs_Allele_Freq[[1]]  - pi_pop )), name = "relative to pop",type = "scatter", mode = "markers") %>%
       add_trace( y = colMeans(abs(Gibbs_Allele_Freq[[1]]  - pi_imp )), name = "relative to implied"))
