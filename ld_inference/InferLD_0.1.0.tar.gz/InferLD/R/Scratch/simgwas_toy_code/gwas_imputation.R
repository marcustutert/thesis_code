recomb_r2   = c()
gwas_r2     = c()
ref_r2      = c()
norecomb_r2 = c()

for (i in 1:1e2) {
  untyped = sort(sample(seq(1:438),200))
  typed = sort(seq(1:438)[-untyped])
  t = impute(ref_panel_haplotypes,
             sites.typed = typed,
             betas       = gwas_ss[typed,2],
             sd.betas    = gwas_ss[typed,3],
             LD          = test)
  norecomb_r2[i] = summary(lm(t~gwas_ss[untyped,2]/gwas_ss[untyped,3]))$r.squared
}
density1 = density(recomb_r2)
density2 = density(gwas_r2)
density3 = density(ref_r2)
density4 = density(norecomb_r2)

p <- plot_ly(x = ~density1$x, y = ~density1$y, type = 'scatter', mode = 'lines', name = 'recomb_r2', fill = 'tozeroy') %>%
  add_trace(x = ~density2$x, y = ~density2$y, name = 'gwas_r2', fill = 'tozeroy') %>%
  add_trace(x = ~density3$x, y = ~density3$y, name = 'ref_r2', fill = 'tozeroy') %>%
  add_trace(x = ~density3$x, y = ~density3$y, name = 'norecomb_r2q', fill = 'tozeroy')

p
