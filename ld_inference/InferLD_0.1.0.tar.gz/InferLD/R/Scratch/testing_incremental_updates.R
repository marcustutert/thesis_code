setwd("/well/mcvean/mtutert/thesis_code/thesis_code/mle_estimator/")
sumstats      = fread("/well/mcvean/ukbb12788/mtutert/test_genotyped_chr1", header = T)
super_pops              = c("EUR","AFR")
matched_pi_ref          = list() #List of the matched pi_refs across super pops
matched_sumstats        = list() #List of the matched sumstats across super pops
matched_snp_id          = list()
matched_gwas_freq       = list()
for (i in 1:length(super_pops)) {
  #Extract out the rsIDs in this region:
  bolt_snp_rsid = bolt_gwas_sumstats$SNP
  #Read in KG freq file
  KG_freq = fread(sprintf("sample_pops/%s_freq.afreq",super_pops[i]),header = T)
  
  #Match the SNPs
  KG_filtered   = KG_freq[which(KG_freq$ID %in% bolt_snp_rsid)]
  bolt_filtered = bolt_gwas_sumstats[which(bolt_gwas_sumstats$SNP  %in% KG_filtered$ID)]
  
  #Get the list of pi_ref freqs and SEs
  pi_ref        = as.numeric(KG_filtered$ALT_FREQS)
  
  bolt_se       = bolt_filtered$SE
  #Remove rare variants in either population
  pi_ref_low_freq  = which(pi_ref > 0.99 | pi_ref < 0.01 | is.na(pi_ref))
  bolt_snps        = bolt_filtered$SNP
  gwas_af          = bolt_filtered$A1FREQ
  if (length(pi_ref_low_freq) > 0 ) {
    pi_ref  = pi_ref[-pi_ref_low_freq]
    bolt_se = bolt_se[-pi_ref_low_freq]
    bolt_snps = bolt_snps[-pi_ref_low_freq]
    gwas_af = gwas_af[-pi_ref_low_freq]
  }
  matched_pi_ref[[i]]    = pi_ref
  matched_sumstats[[i]]  = bolt_se
  matched_snp_id[[i]]    = bolt_snps
  matched_gwas_freq[[i]] = gwas_af
  
  #Calculate mbar (do this manually for now, will cange later)
  #Convert SE^2 to quanitative scale (BOLT Quirk)
  matched_sumstats[[i]]       = (matched_sumstats[[i]]/(0.2201582*(1-0.2201582)))^2
  write.table(x = matched_snp_id[[i]],sprintf("/well/mcvean/mtutert/thesis_code/thesis_code/ld_inference/%s_1000G_SNPs",super_pops[i]), quote = F, row.names = F, col.names = F)
  #Load 1000G panel from these variants
}


mbar                        = (2*361381*0.2201582*(1-0.2201582))
#Do this w UKBB data
ukbb_se       = (bolt_gwas_sumstats$SE/(0.2201582*(1-0.2201582)))^2
ukbb_af       = bolt_gwas_sumstats$A1FREQ


EUR_1000G = as.matrix(fread("/well/mcvean/mtutert/thesis_code/thesis_code/ld_inference/test.haps",header = F, stringsAsFactors = T))
EUR_1000G = t(EUR_1000G[,6:(ncol(EUR_1000G))])
EUR_1000G = `class<-`(EUR_1000G, 'numeric')

AFR_1000G = as.matrix(fread("/well/mcvean/mtutert/thesis_code/thesis_code/ld_inference/AFR_haps",header = F, stringsAsFactors = T))
AFR_1000G = t(AFR_1000G[,6:(ncol(AFR_1000G))])
AFR_1000G = `class<-`(AFR_1000G, 'numeric')
set.seed(55)
nsnps = 5000

#profvis({
results                             = LD_from_GSHMM(ref_allele_matrix     = (AFR_1000G[,1:nsnps]),
                                                    fst                   = 0.05,
                                                    alpha                 = 1e4,
                                                    nSamples              = 5,
                                                    weights_resolution    = 1000,
                                                    likelihood_toggle     = TRUE,
                                                    gwas_variance         = matched_sumstats[[2]][1:nsnps],
                                                    LD_Infer              = FALSE,
                                                    recombination         = FALSE,
                                                    case_control_constant = mbar/2,
                                                    BurnIn                = 0.9,
                                                    debug                 = TRUE)

#})
 

fig <- plot_ly(data = iris, y = ~results$log_likelihood, x = ~seq(1:length(results$log_likelihood)))
fig

plot(matched_gwas_freq[[2]][1:nsnps],rowMeans(results$inferred_af_given_weights[,(.9*length(results$log_likelihood)):length(results$log_likelihood)]))
abline(0,1)

