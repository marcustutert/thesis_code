#Code to test variable recombination rate along the genome
#Download the reference data and gwas_ss
#Run this locally

gwas_ss   = read.table("~/Desktop/Oxford_Dphil/EstimateLD/R/Data/gwas_ss")
ref_panel = read.table("~/Desktop/Oxford_Dphil/EstimateLD/R/Data/ref_panel_filtered")
nSamples  = 10
genetic_map = read.table("~/Desktop/Oxford_Dphil/EstimateLD/R/Data/hmm_recomb_map")[,1]
results = LD_from_GSHMM(se_observed           = gwas_ss[1:100,3]^2/0.001,
                        ref_panel_haplotypes  = as.matrix(unique(ref_panel)[,1:100]),
                        Fst                   = 0.01,
                        alpha                 = 5e2,
                        recomb_rate           = genetic_map[1:100],
                        weights_resolution    = 10,
                        nSamples              = nSamples,
                        likelihood            = TRUE,
                        LD_Infer              = FALSE,
                        noise_factor          = 1/5e2,
                        genetic_map           = FALSE)

x = colSums(results[[2]],na.rm = TRUE)
plot(rowMeans(x))
BurnIn                  = 0.9 #Burn in factor (ie 90%c of data will be discarded)
Post_Burn_Samples       = (BurnIn*nSamples):nSamples
recomb_events = results[[2]][,,Post_Burn_Samples]
x = colSums(recomb_events,na.rm = TRUE,dims = c(1))
plot(x[,1])
