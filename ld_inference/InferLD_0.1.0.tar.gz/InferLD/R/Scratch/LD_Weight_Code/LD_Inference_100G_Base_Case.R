#Scratch code to look at both the speed of the LD inference, and how to simulate replicate from 1000G populations
#What we want is flexible code that will adapt to different number of haplotypes, SNPs, HW_matrix updates
#Want to see how to do this in a nice manner...

#############################.
#Let's start by inferring a bunch of haplotype_weight_matrices from 1000G
#Playground for testing Gibbs sampling of my HMM to predict GWAS haplotypes
library(stats)
library(plotly)
library(data.table)
rm(list = setdiff(ls(), lsf.str()))
###################################################################/
# Reading in the Data from 1000G
###################################################################/

haps = fread("~/Desktop/Oxford_Dphil/EstimateLD/tests/Data/Eur_Chr22_Filtered_First_40K_Variants.haps", header = TRUE)

#Store the SNP base pair distances (so we can calculate the LD r metrics)
SNP_Position = unname(unlist(haps[,3]))
  
haps<-haps[,-1:-5] #Take away all the naming conventions

#Create haplotype column names
hap_names <- sprintf("hap%s",seq(1:ncol(haps)))
colnames(haps) =  hap_names

#Transpose matrix to get it in same form as my other data
haps = t(haps)

###################################################################/
# Pick how big we want reference panel to be and the size of the region
###################################################################/
ref_panel_size = 100
haps           = haps[sample(nrow(haps), ref_panel_size), ]
nsnps          = 100
haps = haps[,1:nsnps]

###################################################################/
# Cleaning and Filtering the Datao
###################################################################/
#Look at the initial pi_ref's make sure that they look ok...
pi_ref = colSums(haps)/nrow(haps)

#Restrict to only variants that are segregating in both populations and have an MAF > 0.1%.
seg_snps     = which(pi_ref<0.95 & pi_ref>0.05)
haps         = haps[,seg_snps]
SNP_Position = SNP_Position[seg_snps]
pi_ref       = colSums(haps)/nrow(haps)

###################################################################/
# Simulating the GWAS SE's from Drifted Pi_Pops
###################################################################/

#Get number of snps and haps from our ref_allele panel (haps)
nsnps = ncol(haps)
nhaps = nrow(haps)

#Now let's generate a list of drifted pi_pop's with NB model
Fst    = 0.001
# c      = 1/Fst-1
# alpha  = c*pi_ref
# beta   = c*(1-pi_ref)
# pi_pop = rbeta(nsnps, alpha, beta) Nichols Balding (infinite recomb.)

#Sample from a Gamma Distribution
sample_weights           = rgamma(n = nhaps, shape = 1/(nhaps*Fst), scale = 1)
normalize_sample_weights = sample_weights/(sum(sample_weights))
pi_pop                   = colSums(haps * normalize_sample_weights)

#Add some multiplicative Gamma noise on top of this
alpha = 1e2 #Larger alpha = smaller noise

#Generate the sigma^2 observed
observed_sigma_b = 1/(pi_pop*(1-pi_pop))*rgamma(nsnps,shape = alpha, scale = 1/alpha)

# #Perform the Gibbs Sampling
# Gibbs_Allele_Freq = Gibbs_Sampling_Allele_Freq_Check(recomb_rate = 1e-4, nSamples = 1e2, weights_resolution =  10, ref_allele_matrix = haps, Fst = Fst)
#
# #################################Sanity Check###############
# pi_imp1 = 0.5 + 0.5*sqrt( 1 - pmin( 4 / observed_sigma_b,1 ))
# pi_imp2 = 0.5 - 0.5*sqrt( 1 - pmin(4 / observed_sigma_b,1 ))
# pi_imp = ifelse( pi_ref > 0.5, pi_imp1, pi_imp2)
#
# show(plot_ly( y = colMeans(abs(Gibbs_Allele_Freq  - pi_pop )), name = "relative to pop",type = "scatter", mode = "markers") %>% add_trace( y = colMeans(abs(Gibbs_Allele_Freq  - pi_imp )), name = "relative to implied"))

##############################################################.
################################# LD Inference ###############
##############################################################.

# #Define variables
# nSamples                = 100
# sampled_population_size = 2000
# burnIn                  = 50
# 
# #Do the Gibbs Sampling process, store the results to an array
# HW_Array    = Gibbs_Sampling_HW_Array(recomb_rate = 1e-4, nSamples = nSamples, weights_resolution =  20, ref_allele_matrix = haps, Fst = Fst)
# #Store the pseudo_haplotypes in an array
# pseudo_haps = array(data = rep(NA,sampled_population_size*nsnps*nSamples), dim = c(sampled_population_size,nsnps,nSamples))
# 
# #Loop through the entire Gibbs Sampling Array and calculate markovian flow for each one (this means each loop will produce its own Qx array)
# for (i in 1:nSamples) {
#   cat( sprintf("\r%d", i))
#   #Calculate the Qx flow matrices (using the markovian process)
#   Qx_Array    = markovian_flow(HW_Matrix = HW_Array[,,i], start = 1, end = nsnps) #We have one array for each HW_Array slice
#   #Store our inferred_haplotypes in a matrix
#   pseudo_haps[,,i] = descendant_haplotypes(Qx_array = Qx_Array, ref_allele_matrix = haps, HW_Matrix = HW_Array[,,i], sampled_population_size = sampled_population_size)
# }
# 
# #Calculate the LD, and take the averages across all the samples
# LD_Inferred = array(data = rep(NA,nsnps*nsnps*(nSamples-burnIn)), dim = c(nsnps,nsnps,(nSamples-burnIn)))
# for (i in burnIn:nSamples) {
#   LD_Inferred[,,(i-burnIn)] = LD_Matrix(haplotypes = pseudo_haps[,,i])
# }

# #Get the LD averages from the pseudo-haplotypes (across all SNPs) and the real haplotypes and compare the two of them
# LD_Inferred_Averages <- apply(LD_Inferred, c(1,2), mean)
# p <- plot_ly(z = LD_Inferred_Averages, type = "heatmap")
# p
# #Get the TRUE LD, in matrix form
# LD_True =  LD_Matrix(haplotypes = haps)
# q <- plot_ly(z = LD_True, type = "heatmap")
# q
# 
# #Get the total error between the two
# print(min(abs(LD_Inferred_Averages - LD_True)))
# 
# #Heatmap that show the LD Differences
# LD_Differences = LD_Inferred_Averages - LD_True
# r <- plot_ly(z = LD_Differences, type = "heatmap")
# r
# 
# #We want to plot for a single SNP the Distance vs True/Implied r LD metric
# #Get the SNP (#45 here) LD across all SNPs
# 
# plot(SNP_Position,LD_Inferred_Averages[46,]/LD_True[46,])
# plot(rep(SNP_Position,96),(LD_Inferred_Averages-LD_True))
# 
# #Plot the errors
# pseudo_sample_pop_size = c(100,200,300,400,500,600,700,800)
# means_abs_error        = c(0.03016027,0.02228337,0.01778076,0.01452099,0.0118422,0.009699252,0.007362769,0.005727172)
# max_abs_error          = c(0.172976,0.132728,0.1142491,0.089176,0.06909648,0.06129878,0.04137535,0.02871944)
# data = cbind.data.frame(pseudo_sample_pop_size,means_abs_error,max_abs_error)
# 
# p <- plot_ly(data, x = ~data$pseudo_sample_pop_size) %>%
#   add_trace(y = ~data$means_abs_error, name = 'means abs error',mode = 'markers') %>%
#   add_trace(y = ~data$max_abs_error, name = 'max abs error', mode = 'markers')

#####Storing the LD matrices Iteratively#####
LD_Inferred_Averages_Array = array(data = rep(NA,nsnps*nsnps*8), dim = c(nsnps,nsnps,8))
for (j in seq(100,800,by = 100)) {
  cat( sprintf("\r%d", j))
  #Define variables
  nSamples                = 100
  sampled_population_size = j
  burnIn                  = 50
  
  #Do the Gibbs Sampling process, store the results to an array
  HW_Array    = Gibbs_Sampling_HW_Array(recomb_rate = 1e-4, nSamples = nSamples, weights_resolution =  20, ref_allele_matrix = haps, Fst = Fst)
  #Store the pseudo_haplotypes in an array
  pseudo_haps = array(data = rep(NA,sampled_population_size*nsnps*nSamples), dim = c(sampled_population_size,nsnps,nSamples))
  
  #Loop through the entire Gibbs Sampling Array and calculate markovian flow for each one (this means each loop will produce its own Qx array)
  for (i in 1:nSamples) {
    cat( sprintf("\r%d", i))
    #Calculate the Qx flow matrices (using the markovian process)
    Qx_Array    = markovian_flow(HW_Matrix = HW_Array[,,i], start = 1, end = nsnps) #We have one array for each HW_Array slice
    #Store our inferred_haplotypes in a matrix
    pseudo_haps[,,i] = descendant_haplotypes(Qx_array = Qx_Array, ref_allele_matrix = haps, HW_Matrix = HW_Array[,,i], sampled_population_size = sampled_population_size)
  }
  
  #Calculate the LD, and take the averages across all the samples
  LD_Inferred = array(data = rep(NA,nsnps*nsnps*(nSamples-burnIn)), dim = c(nsnps,nsnps,(nSamples-burnIn)))
  for (i in burnIn:nSamples) {
    LD_Inferred[,,(i-burnIn)] = LD_Matrix(haplotypes = pseudo_haps[,,i])
  }
  LD_Inferred_Averages_Array[,,j/100] <- apply(LD_Inferred, c(1,2), mean)
}

#Plot all the matrices
LD2 <- plot_ly(z = LD_Inferred_Averages_Array[,,2], type = "heatmap")
LD2
