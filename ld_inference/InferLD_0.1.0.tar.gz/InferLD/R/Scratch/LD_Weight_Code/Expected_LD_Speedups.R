###Code for Testing Speedups of the expected LD flow ######

#Note that these functions won't be tested for their accuracy, use the "LD_Inference_Toy_Problem.R" for a easy 4x3 case to check accuracy!

######Create data#######
#Specify dimensionality (nhaps and nsnps)
nsnps = 10
nhaps = 1000
#Build the haplotype weight matrix
#Choose from gamma quantiled weights so that we center around an LD_r ~= 0
Gamma_Quantiled_Weights = qgamma(p = (1:20)/(1+20), shape = 1 / ( nhaps * 1e-5 ), scale = 1 )
Gamma_Quantiled_Weights = Gamma_Quantiled_Weights[is.finite(Gamma_Quantiled_Weights) & Gamma_Quantiled_Weights > 0 ]
HW_Matrix         = matrix(data = Gamma_Quantiled_Weights[1], nrow = nhaps, ncol = nsnps) #This will be unnormalized
ref_allele_matrix = matrix(sample(size = nsnps * nhaps, x = 0:1, replace = TRUE), nrow = nhaps, ncol = nsnps)

#Function to generate the Qx matrices
markovian_flow = function(HW_Matrix, start, end){
  #Get constants we need
  nsnps = ncol(HW_Matrix)
  nhaps = nrow(HW_Matrix)
  length = end - start #Length of genome that we will be inferring/using for downstream applications

  #Create a 3D array of Q^x matrices that will store the markovian transition flows
  Qx_array = array(rep(NA,nhaps*nhaps*length), dim = c(nhaps,nhaps,length))

  ####### Case 1: i != j, the Non-Diagonal elements of the Q^x array #########

  #We will loop over each locus (except for the last one, and store the results into the respective Qx arrays )
  for (i in seq(1,nsnps-1)) {
    #flow leaving i @ x
    delta_i_x   = apply(cbind(c(HW_Matrix[,i]-HW_Matrix[,i+1]),rep(0,nhaps)), 1, FUN = max)
    #flow entering @ x+1
    delta_j_x_1 = apply(cbind(c(HW_Matrix[,i+1]-HW_Matrix[,i]),rep(0,nhaps)), 1, FUN = max)
    #flow normalization constant (w_i^x * sum(delta_j_x_1)), will be different for each i & j
    delta_total = HW_Matrix[,i]*sum(delta_i_x)

    #Caclulate the outer products based on the delta's we calculated above and assign them to the Q^x array
    Qx_array[,,i] = sweep(outer(delta_i_x, delta_j_x_1, FUN = '*'), 1, delta_total, FUN = '/')
    #Replace NAN's with 0's
    Qx_array[,,i][is.nan(Qx_array[,,i])] <- 0
  }

  ###### Case 2: i = j, the Diagonal elements of the Q^x array #########

  diag_elements = matrix(data = NA, nrow = nhaps, ncol = nsnps-1)
  #Create a for loop, that goes through the HW matrix and gets the minimum of each each succesive column (and across each row)
  for (i in seq(1,nsnps-1) ) { #Loop across the X's
    diag_elements[,i] = apply(HW_Matrix[,i:(i+1)], 1, FUN = min)/HW_Matrix[,i] #Also need to normalize this by the w_i^x
  }

  #Deal with the case when we are dividing by zero (currently this is impossible under the Haplotype Inference framework since we don't have zero weights)
  diag_elements[is.nan(diag_elements)] <- 1

  #Melt this matrix to a vector
  diag_elements = c(diag_elements)

  #### Diagonal Array Replacement Function ####
  `arraydiag` <- function(x,value){
    dims <- dim(x)
    id <- seq_len(dims[1]) +
      dims[2]*(seq_len(dims[2])-1)
    id <- outer(id,(seq_len(dims[3])-1)*prod(dims[1:2]),`+`)
    x[c(id)] <- value
    dim(x) <- dims
    x
  }

  #Replace the diagonal elements with this diag_elements vector using function above
  Qx_array = `arraydiag`(x = Qx_array ,value = diag_elements)

  #Return the modified and populated Qx array
  return(Qx_array)
}

Qx_array = markovian_flow(HW_Matrix = HW_Matrix, start = 1, end = nsnps) #Get the Qx arrays from the markov flow

profvis({
LD_flow_expectation  = function(HW_Matrix, ref_allele_matrix, Qx_array){
  #Get the dimensions of the Qx array
  nhaps       = nrow(ref_allele_matrix)
  nsnps       = ncol(ref_allele_matrix)
  weights_sum = sum(HW_Matrix[,1])

  #Get a matrix to store the LD_results (this will have dimensions nsnps x nsnps)
  LD_Values = matrix(data = NA, nrow = nsnps, ncol = nsnps)

  #####Prestore the allele frequencies #######
  allele_frequencies = c()

  for (k in 1:nsnps) { #This is just the weighted sum across haplotypes encoded ==1
    allele_frequencies[k] = sum(ref_allele_matrix[,k]*HW_Matrix[,k])/(sum(HW_Matrix[,k]))
  }

  #Calculate LD across SNPs
  for (i in 1:(nsnps-1)) { #Loop through upper triangle of this matrix
    print(i)

    Qx_Multiplied = Qx_array[,,i] #Store the first Qx array
    #We will also need to keep track of where along the nsnps we are (using a counter)
    counter = 1

    for (j in i:nsnps) { #Will flip and mirror LD values later
      if (abs(i-j) == 1) { #Adjacent SNP case

        #Formula for covariance
        #browser()
        d = diag(HW_Matrix[,i])
        m = eigenMapMatMult(d,Qx_array[,,i])
        o = outer(ref_allele_matrix[,i],ref_allele_matrix[,j])
        f_11_covariance = sum(m * o)/weights_sum
        f_1_A                  = allele_frequencies[i]
        f_1_B                  = allele_frequencies[j]
        LD_r                   = (f_11_covariance - f_1_A * f_1_B)/(sqrt(f_1_A*(1-f_1_A)*f_1_B*(1-f_1_B)))
        LD_Values[i,j]         = LD_r
      }
      if (abs(i-j)>1) { #Long Distance Case, this is when will be dealing with Qx matrix multiplication
        Qx_Multiplied  = eigenMapMatMult(Qx_Multiplied,Qx_array[,,i + counter]) #Store the RECURSIVE multiplication result
        counter = counter + 1 #Add to counter

        #Perform the covariance calculation, this has similar formula to adjacent case
        #browser()
        #x_i_i_plus_one = as.vector(t(ref_allele_matrix[,i] %*% ( diag(HW_Matrix[,i]) %*% (Qx_Multiplied))))
        weighted_flow_matrix = (Qx_Multiplied * (HW_Matrix[,i]))
        ref_indicator        = ref_allele_matrix[,i]
        x_i_i_plus_one       = crossprod( ref_indicator, weighted_flow_matrix )

        #Can perform the final matrix operation as dot product operation since we have a vector now
        f_11_covariance = sum(x_i_i_plus_one*ref_allele_matrix[,j])/weights_sum
        #Calculate LD using covariance and allele frequencies
        f_1_A                  = allele_frequencies[min(i,j)]
        f_1_B                  = allele_frequencies[max(i,j)]
        LD_r                   = (f_11_covariance - f_1_A * f_1_B)/(sqrt(f_1_A*(1-f_1_A)*f_1_B*(1-f_1_B)))
        LD_Values[i,j]         = LD_r
      }
    }
  }
  #Add on the values along the diagonal
  diag(LD_Values) <- 1
  #Flip the symmetric matrix around diagonal to fill in the lower half of the triangle
  LD_Values[lower.tri(LD_Values)] <- t(LD_Values)[lower.tri(LD_Values)]
  return(LD_Values)
}



#### Results #####
LD_flow_expectation(HW_Matrix = HW_Matrix, ref_allele_matrix = ref_allele_matrix, Qx_array = Qx_array)})

